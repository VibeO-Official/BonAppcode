<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Путеводная звезда

Голодные клиенты получают еду Bon App с доставкой или навынос.

## Метрика

Заказы, оформленные за неделю
