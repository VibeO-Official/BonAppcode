CREATE TABLE public.news_reactions (
  post_id text NOT NULL,
  visitor_id uuid NOT NULL,
  emoji text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (post_id, visitor_id)
);
GRANT ALL ON public.news_reactions TO service_role;
ALTER TABLE public.news_reactions ENABLE ROW LEVEL SECURITY;