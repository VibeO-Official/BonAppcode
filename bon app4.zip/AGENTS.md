<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Preserve the uploaded TanStack storefront routes and shared shop provider to retain the original menu, cart, delivery and checkout.
- Keep homepage advertising in a dedicated Embla carousel with a tested autoplay hook; this isolates swipe/navigation behavior from the storefront and preserves its shared provider.
- Store imported photos as Lovable Assets JSON pointers so uploaded media stays outside the source bundle.
- Keep light and dark appearance in shared semantic CSS tokens and one header control so every page switches together.
- Validate and price guest orders in the server function; read TELEGRAM_BOT_TOKEN only inside its handler and never expose credentials or customer data in logs.
- Keep the AI chat assistant fully in-browser (WebLLM, lazy-imported on first message) so it needs no API key or server.
- Resolve reply-language instructions from the latest visitor message in a tested browser-safe helper, not the storefront locale, so switching languages in chat does not inherit earlier replies.
- Read channel news server-side from the public t.me/s/<channel> preview page, because it needs no bot admin rights, webhook or database.
