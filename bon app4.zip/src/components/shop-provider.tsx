import { createContext,useContext,useState,type ReactNode } from 'react';
import { products } from '@/lib/menu';
type Shop={cart:Record<string,number>;change:(id:string,delta:number)=>void;clear:()=>void;count:number;total:number;cartOpen:boolean;setCartOpen:(open:boolean)=>void};
const ShopContext=createContext<Shop|undefined>(undefined);
export function ShopProvider({children}:{children:ReactNode}){const [cart,setCart]=useState<Record<string,number>>({});const [cartOpen,setCartOpen]=useState(false);const change=(id:string,delta:number)=>setCart(prev=>{const next={...prev};const quantity=Math.min(20,Math.max(0,(next[id]??0)+delta));if(quantity)next[id]=quantity;else delete next[id];return next;});return <ShopContext.Provider value={{cart,change,clear:()=>setCart({}),count:Object.values(cart).reduce((a,b)=>a+b,0),total:products.reduce((a,p)=>a+p.price*(cart[p.id]??0),0),cartOpen,setCartOpen}}>{children}</ShopContext.Provider>}
export function useShop(){const value=useContext(ShopContext);if(!value)throw new Error('ShopProvider missing');return value;}
