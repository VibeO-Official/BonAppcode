import { useEffect, useRef, useState } from 'react';
import { Search, LocateFixed, LoaderCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { YANDEX_MAPS_API_KEY } from '@/lib/yandex-config';

type Coordinates = [number, number];
type MapEvent = { get: (name: string) => Coordinates };
type Marker = { geometry: { setCoordinates: (coordinates: Coordinates) => void } };
type YandexMap = {
  events: { add: (event: string, callback: (event: MapEvent) => void) => void };
  geoObjects: { add: (marker: Marker) => void };
  setCenter: (coordinates: Coordinates, zoom?: number) => void;
  destroy: () => void;
};
type YandexApi = {
  ready: (callback: () => void) => void;
  Map: new (element: HTMLElement, state: object, options?: object) => YandexMap;
  Placemark: new (coordinates: Coordinates, properties: object, options: object) => Marker;
  geocode: (query: Coordinates | string, options?: object) => Promise<{geoObjects: {get: (index: number) => {
    getAddressLine: () => string;
    geometry: {getCoordinates: () => Coordinates};
    properties: {get: (name: string) => unknown};
  } | undefined}}>;
};
declare global { interface Window { ymaps?: YandexApi } }

const NOMINATIM = 'https://nominatim.openstreetmap.org';
type NominatimPlace = {lat: string; lon: string; display_name?: string; addresstype?: string; address?: Partial<Record<'city'|'town'|'village'|'county'|'state'|'suburb'|'neighbourhood'|'quarter'|'road'|'pedestrian'|'house_number', string>>};
function shortAddress(place: NominatimPlace): string {
  const a = place.address ?? {};
  const city = a.city || a.town || a.village || a.county || a.state || '';
  const area = a.suburb || a.neighbourhood || a.quarter || '';
  const street = a.road || a.pedestrian || '';
  const parts = [city, area, street && (a.house_number ? `${street}, ${a.house_number}` : street)].filter(Boolean);
  return parts.length ? parts.join(', ') : (place.display_name ?? '');
}
async function reverseLookup([lat, lon]: Coordinates): Promise<string | undefined> {
  const r = await fetch(`${NOMINATIM}/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1&accept-language=uz,ru`);
  if (!r.ok) throw new Error('reverse failed');
  const place = await r.json() as NominatimPlace;
  return place.display_name ? shortAddress(place) : undefined;
}
async function forwardLookup(query: string): Promise<{coordinates: Coordinates; kind?: string | undefined} | undefined> {
  const r = await fetch(`${NOMINATIM}/search?format=jsonv2&limit=1&countrycodes=uz&viewbox=68.4,40.8,69.2,40.2&q=${encodeURIComponent(query)}&accept-language=uz,ru`);
  if (!r.ok) throw new Error('search failed');
  const [place] = await r.json() as NominatimPlace[];
  return place ? {coordinates: [Number(place.lat), Number(place.lon)], kind: place.addresstype} : undefined;
}

let apiPromise: Promise<YandexApi> | undefined;
function loadMaps(key: string): Promise<YandexApi> {
  if (apiPromise) return apiPromise;
  apiPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `https://api-maps.yandex.ru/2.1/?apikey=${encodeURIComponent(key)}&lang=ru_RU`;
    script.async = true;
    script.onload = () => {
      const api = window.ymaps;
      if (!api) { reject(new Error('Yandex Maps unavailable')); return; }
      api.ready(() => resolve(api));
    };
    script.onerror = () => { script.remove(); apiPromise = undefined; reject(new Error('Yandex Maps failed to load')); };
    document.head.appendChild(script);
  });
  return apiPromise;
}

export function DeliveryMap({ address, onAddressChange, onSelect }: {
  address: string;
  onAddressChange: (address: string) => void;
  onSelect: (coordinates: Coordinates | undefined, address?: string) => void;
}) {
  const key = YANDEX_MAPS_API_KEY;
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<YandexMap | null>(null);
  const select = useRef(onSelect);
  select.current = onSelect;
  const choose = useRef<((coordinates: Coordinates) => void) | null>(null);
  const apiRef = useRef<YandexApi | null>(null);
  const version = useRef(0);
  const typedAddress = useRef('');
  const addressChange = useRef(onAddressChange);
  addressChange.current = onAddressChange;
  const forward = useRef<((query: string) => void) | null>(null);
  const [status, setStatus] = useState('loading');
  const [locationError, setLocationError] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (!key) return;
    let disposed = false;
    loadMaps(key).then(api => {
      if (disposed || !container.current) return;
      apiRef.current = api;
      const instance = new api.Map(container.current, { center: [40.4897, 68.7842], zoom: 12, controls: ['zoomControl'] }, { suppressMapOpenBlock: true, yandexMapDisablePoiInteractivity: true });
      map.current = instance;
      let marker: Marker | null = null;
      const placeMarker = (coordinates: Coordinates) => {
        if (!marker) {
          marker = new api.Placemark(coordinates, {}, { preset: 'islands#redDeliveryIcon', draggable: false });
          instance.geoObjects.add(marker);
        } else marker.geometry.setCoordinates(coordinates);
      };
      choose.current = coordinates => {
        placeMarker(coordinates);
        typedAddress.current = '';
        setSearchQuery('');
        addressChange.current('');
        select.current(undefined);
        setSearching(true);
        setSearchError('');
        const currentVersion = ++version.current;
        const fallback = `Xaritadagi nuqta: ${coordinates[0].toFixed(6)}, ${coordinates[1].toFixed(6)}`;
        reverseLookup(coordinates).then(found => {
          if (disposed || currentVersion !== version.current) return;
          const selectedAddress = found || fallback;
          addressChange.current(selectedAddress);
          select.current(coordinates, selectedAddress);
        }).catch(() => {
          if (disposed || currentVersion !== version.current) return;
          addressChange.current(fallback);
          select.current(coordinates, fallback);
        }).finally(() => {if (!disposed && currentVersion === version.current) setSearching(false);});
      };
      forward.current = query => {
        const currentVersion = ++version.current;
        setSearching(true);
        setSearchError('');
        forwardLookup(query).then(location => {
          if (disposed || currentVersion !== version.current || typedAddress.current !== query) return;
          if (!location) {setSearchError('Manzil topilmadi. Shahar va ko‘cha nomini aniqlashtiring yoki xaritadan tanlang.'); return;}
          const {coordinates, kind} = location;
          placeMarker(coordinates);
          instance.setCenter(coordinates, kind === 'building' || kind === 'house' ? 17 : kind === 'road' ? 16 : 14);
          // Preserve the customer's typed house/apartment details while moving the map.
          select.current(coordinates);
        }).catch(() => {
          if (!disposed && currentVersion === version.current) setSearchError('Qidiruv ishlamadi. Manzilni yozing yoki xaritadan tanlang.');
        }).finally(() => {if (!disposed && currentVersion === version.current) setSearching(false);});
      };
      instance.events.add('click', event => choose.current?.(event.get('coords')));
      setStatus('ready');
    }).catch(() => { if (!disposed) setStatus('error'); });
    return () => { disposed = true; ++version.current; map.current?.destroy(); map.current = null; apiRef.current = null; choose.current = null; forward.current = null; };
  }, [key]);

  useEffect(() => {
    if (status !== 'ready' || searchQuery.trim().length < 3) return;
    const timer = window.setTimeout(() => forward.current?.(searchQuery.trim()), 500);
    return () => window.clearTimeout(timer);
  }, [searchQuery, status]);

  function editAddress(value: string) {
    ++version.current;
    typedAddress.current = value.trim();
    setSearching(false);
    setSearchError('');
    setSearchQuery(value);
    onAddressChange(value);
    onSelect(undefined);
  }

  function locate() {
    if (!navigator.geolocation) { setLocationError('Joylashuvni aniqlash imkoni yo‘q.'); return; }
    setLocationError('');
    navigator.geolocation.getCurrentPosition(position => {
      const coordinates: Coordinates = [position.coords.latitude, position.coords.longitude];
      map.current?.setCenter(coordinates, 16);
      choose.current?.(coordinates);
    }, () => setLocationError('Joylashuvga ruxsat berilmadi. Manzilni xaritadan tanlang.'), { timeout: 10000 });
  }

  return <div className="delivery-map-block">
    <div className="delivery-address-search"><label className="field"><span className="sr-only">Manzil</span><textarea required minLength={5} name="address" autoComplete="street-address" maxLength={500} placeholder="Shahar, ko‘cha, uy va xonadon raqami" value={address} onChange={event => editAddress(event.target.value)} onKeyDown={event => {if (event.key === 'Enter' && !event.shiftKey) {event.preventDefault(); forward.current?.(typedAddress.current);}}}/></label><Button type="button" variant="ghost" size="icon" className="address-search-button" aria-label="Manzilni qidirish" title="Manzilni qidirish" disabled={status !== 'ready' || address.trim().length < 3 || searching} onClick={() => {typedAddress.current = address.trim(); forward.current?.(typedAddress.current);}}>{searching ? <LoaderCircle className="animate-spin motion-reduce:animate-none" size={18}/> : <Search size={18}/>}</Button></div>
    {searchError && <p className="field-error map-search-error" role="alert">{searchError}</p>}
    <div className="delivery-map-frame"><div ref={container} className="delivery-map-canvas" aria-label="Yetkazib berish joyini tanlash uchun Yandex xaritasi"/>{key && status === 'ready' && <Button type="button" variant="outline" size="icon" className="map-locate-button" aria-label="Joylashuvim" title="Joylashuvim" onClick={locate}><LocateFixed size={18}/></Button>}{status !== 'ready' && <p className="map-message" role="status">{status === 'error' ? 'Xarita yuklanmadi. Manzilni yuqorida yozing.' : 'Xarita yuklanmoqda…'}</p>}</div>
    {locationError && <p className="field-error" role="alert">{locationError}</p>}
  </div>;
}