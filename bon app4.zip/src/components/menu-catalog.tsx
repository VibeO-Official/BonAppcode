import { useState } from 'react';
import { Link } from '@tanstack/react-router';
import { Plus,ArrowUpRight,Search,BadgePercent } from 'lucide-react';
import { Button } from './ui/button';
import { categories,products,money } from '@/lib/menu';
import { useShop } from './shop-provider';
import { Quantity, flyToCart } from './shop-shell';
import { useI18n } from '@/lib/i18n';
export function CategoryBar({selected,onSelect}:{selected:string;onSelect:(id:string)=>void}){const {cat}=useI18n();return <div className="category-bar">{categories.map(c=><Button key={c.id} variant="category" className={`category-button ${selected===c.id?'selected':''}`} aria-pressed={selected===c.id} onClick={()=>onSelect(c.id)}>{c.id==='all'?<span className="category-promo" aria-hidden="true"><BadgePercent/></span>:<img className="category-thumb" src={products.find(p=>p.category===c.id)?.image} alt="" width={35} height={35}/>}{cat(c.id,c.name)}</Button>)}</div>}
export function MenuCatalog({selected='all',compact=false}:{selected?:string;compact?:boolean}){
 const [query,setQuery]=useState('');const {cart,change}=useShop();const {t,cat,prod}=useI18n();
 const q=query.trim().toLowerCase();
 const shown=products.map(p=>({...p,...prod(p.id,p.name,p.description)})).filter(p=>(selected==='all'||p.category===selected)&&(p.name.toLowerCase().includes(q)||p.description.toLowerCase().includes(q)));
 const catName=categories.find(c=>c.id===selected);
 return <section id="taomlar"><div className="section-heading"><div><p className="overline">{t('overline')}</p><h2 className="section-title">{selected==='all'||!catName?t('favourites'):cat(catName.id,catName.name)}<span className="text-primary">.</span></h2></div>{compact?<Link to="/menu" className="heading-link">{t('allFood')} <ArrowUpRight size={17}/></Link>:<label className="search-box"><Search/><input placeholder={t('search')} aria-label={t('search')} maxLength={80} value={query} onChange={e=>setQuery(e.target.value)}/></label>}</div>{shown.length===0?<div className="no-results">{t('notFound')}</div>:<div className="product-grid">{shown.map(p=><article className="product" key={p.id}>{p.badge&&<span className={`product-badge ${p.badge==='Yangi'?'fresh':''}`}>{p.badge==='Bestseller'?'★ Bestseller':t('newBadge')}</span>}<img className="product-image" src={p.image} width={400} height={512} loading="lazy" alt={p.name}/><div className="product-info"><h3>{p.name}</h3><p>{p.description}</p><div className="product-bottom"><span className="product-price">{money(p.price)} <small>{t('sum')}</small></span>{cart[p.id]?<Quantity id={p.id}/>:<Button className="add-button" size="icon" aria-label={`${p.name} ${t('add')}`} onClick={e=>{flyToCart(e.currentTarget,{message:`${p.name} ${t('added')}`});change(p.id,1)}}><Plus/></Button>}</div></div></article>)}</div>}</section>}
