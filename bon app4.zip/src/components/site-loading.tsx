import { useEffect, useState } from 'react';

// Fully code-drawn loader (no images): yellow screen, buns slide in above and
// below the stroked "Bon App" word, and a thin bar fills underneath.
export function SiteLoading() {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const t = setTimeout(() => setVisible(false), 2500);
    return () => { clearTimeout(t); document.body.style.overflow = prev; };
  }, []);
  useEffect(() => { if (!visible) document.body.style.overflow = ''; }, [visible]);
  if (!visible) return null;

  return (
    <div className="bl-root" role="status" aria-label="Bon App">
      <div className="bl-stack">
        <svg className="bl-svg" viewBox="0 0 820 330" aria-hidden="true">
          <g className="bl-top">
            <path className="bl-bun" d="M130 116 Q130 30 280 30 Q430 30 430 116 Q430 122 418 122 H142 Q130 122 130 116 Z" />
            <ellipse className="bl-seed" cx="230" cy="58" rx="11" ry="6" />
            <ellipse className="bl-seed" cx="270" cy="76" rx="11" ry="6" />
            <ellipse className="bl-seed" cx="300" cy="48" rx="6" ry="10" />
            <ellipse className="bl-seed" cx="345" cy="72" rx="11" ry="6" />
          </g>
          <text className="bl-word" x="160" y="222" textAnchor="start"><tspan className="bon">Bon</tspan><tspan className="app" dx="18">App</tspan></text>
          <rect className="bl-bun bl-bottom" x="130" y="246" width="300" height="52" rx="26" />
        </svg>
        <div className="bl-bar"><span /></div>
      </div>
    </div>
  );
}
