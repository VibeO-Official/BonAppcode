import { useCallback, useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import useEmblaCarousel from 'embla-carousel-react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
import { usePromoAutoplay, PROMO_INTERVAL } from '@/hooks/use-promo-autoplay';
import burger from '@/assets/ad-burger.jpg';
import pizza from '@/assets/ad-pizza.jpg';
import combo from '@/assets/ad-combo.jpg';
import dessert from '@/assets/ad-dessert.jpg';

const slides = [
  { image: burger, alt: 'Bon Burger' },
  { image: pizza, alt: 'Pepperoni' },
  { image: combo, alt: 'Mix Combo' },
  { image: dessert, alt: 'Shirin zavq' },
];

export function PromoCarousel() {
  const { lang } = useI18n();
  const [viewport, api] = useEmblaCarousel({ loop: true, duration: 30 });
  const [selected, setSelected] = useState(0);
  const [hidden, setHidden] = useState(false);
  const next = useCallback(() => api?.scrollNext(), [api]);

  useEffect(() => {
    if (!api) return;
    const update = () => setSelected(api.selectedScrollSnap());
    update();
    api.on('select', update);
    return () => { api.off('select', update); };
  }, [api]);
  useEffect(() => {
    const update = () => setHidden(document.hidden);
    document.addEventListener('visibilitychange', update);
    return () => document.removeEventListener('visibilitychange', update);
  }, []);
  usePromoAutoplay(next, Boolean(api) && !hidden, selected);

  const labels = lang === 'ru'
    ? { carousel: 'Реклама Bon App', prev: 'Назад', next: 'Вперёд', slide: 'Реклама' }
    : lang === 'uz'
      ? { carousel: 'Bon App reklamalari', prev: 'Oldingi', next: 'Keyingi', slide: 'Reklama' }
      : { carousel: 'Bon App promotions', prev: 'Previous', next: 'Next', slide: 'Promotion' };

  return <section className="promo-carousel" role="region" aria-roledescription="carousel" aria-label={labels.carousel}
    onKeyDown={e => { if (e.key === 'ArrowLeft') api?.scrollPrev(); if (e.key === 'ArrowRight') api?.scrollNext(); }}>
    <h1 className="sr-only">Bon App</h1>
    <div className="promo-viewport" ref={viewport}>
      <div className="promo-track">
        {slides.map((slide, index) => <div className={`promo-slide${selected === index ? ' is-active' : ''}`} key={slide.image} role="group" aria-roledescription="slide" aria-label={`${index + 1} / ${slides.length}`} aria-hidden={selected !== index}>
          <Link to="/menu" tabIndex={selected === index ? 0 : -1} aria-label={slide.alt}>
            <img className="promo-image" src={slide.image} alt={slide.alt} width={1920} height={640} loading={index === 0 ? 'eager' : 'lazy'} draggable={false}/>
          </Link>
        </div>)}
      </div>
    </div>
    <Button variant="nav" size="icon" className="promo-arrow promo-prev" aria-label={labels.prev} onClick={() => api?.scrollPrev()}><ChevronLeft/></Button>
    <Button variant="nav" size="icon" className="promo-arrow promo-next" aria-label={labels.next} onClick={next}><ChevronRight/></Button>
    <div className="promo-dots">{slides.map((slide, index) => <button key={slide.image} type="button" className={`promo-dot${selected === index ? ' is-selected' : ''}`} aria-label={`${labels.slide} ${index + 1}`} aria-current={selected === index ? 'true' : undefined} onClick={() => api?.scrollTo(index)}><span/></button>)}</div>
    <div className="promo-progress" aria-hidden="true">
      <span key={`${selected}-${hidden}`} className={hidden ? '' : 'is-running'} style={{ animationDuration: `${PROMO_INTERVAL}ms` }}/>
    </div>
  </section>;
}
