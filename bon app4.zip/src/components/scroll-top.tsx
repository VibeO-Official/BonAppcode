import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';

const R = 22, C = 2 * Math.PI * R;

export function ScrollTop() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const on = () => {
      const el = document.body.scrollTop > 0 ? document.body : document.documentElement;
      const max = el.scrollHeight - el.clientHeight;
      const y = Math.max(window.scrollY, el.scrollTop);
      setP(max > 0 ? Math.min(1, y / max) : 0);
    };
    on();
    document.addEventListener('scroll', on, { passive: true, capture: true });
    window.addEventListener('resize', on);
    return () => { document.removeEventListener('scroll', on, { capture: true }); window.removeEventListener('resize', on); };
  }, []);
  return (
    <button type="button" className={`scroll-top ${p > 0.02 ? 'is-visible' : ''}`} aria-label="Up" title="Up"
      onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }); document.body.scrollTo({ top: 0, behavior: 'smooth' }); }}>
      <svg viewBox="0 0 50 50" aria-hidden="true">
        <circle cx="25" cy="25" r={R} className="scroll-top-track" />
        <circle cx="25" cy="25" r={R} className="scroll-top-bar" strokeDasharray={C} strokeDashoffset={C * (1 - p)} />
      </svg>
      <ArrowUp />
    </button>
  );
}
