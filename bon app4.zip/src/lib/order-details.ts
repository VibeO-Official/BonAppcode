import { products, money } from './menu';
import type { OrderInput } from './order-schema';

export const TELEGRAM_ORDER_CHAT_ID = '-1004434173069';
export function orderDetails(input: OrderInput) {
  const items = input.items.map(item => {
    const product = products.find(product => product.id === item.id);
    if (!product) throw new Error('Noma’lum taom');
    return {id: product.id, name: product.name, price: product.price, quantity: item.quantity};
  });
  return {items, total: items.reduce((sum, item) => sum + item.price * item.quantity, 0)};
}
export function telegramOrderText(input: OrderInput, details: ReturnType<typeof orderDetails>) {
  // Plain text avoids HTML/Markdown injection from customer fields.
  return [
    '🍔 BON APP · YANGI BUYURTMA', `№ ${input.requestId}`, '',
    `👤 Mijoz: ${input.name}`, `📞 Telefon: ${input.phone}`,
    `📍 Manzil: ${input.address}`,
    ...(input.coordinates ? [`🗺 Xarita: https://yandex.uz/maps/?pt=${input.coordinates[1]},${input.coordinates[0]}&z=17&l=map`] : []), '',
    '🛍 BUYURTMA TARKIBI',
    ...details.items.map(item => `• ${item.name} × ${item.quantity} — ${money(item.price * item.quantity)} so‘m`),
    '', `💰 Taomlar jami: ${money(details.total)} so‘m`,
    `💳 To‘lov: ${input.payment === 'cash' ? 'Naqd pul' : 'Terminal'}`,
    '🚚 Yetkazib berish narxi va vaqti: operator tasdiqlaydi',
    ...(input.note ? ['', `📝 Izoh: ${input.note}`] : []),
  ].join('\n');
}