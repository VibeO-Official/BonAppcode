import burger from '@/assets/dish-burger.png';
import chicken from '@/assets/dish-chicken.png';
import pizza from '@/assets/dish-pizza.png';
import sushi from '@/assets/dish-sushi.png';
import fries from '@/assets/dish-fries.png';
import cola from '@/assets/dish-cola.png';
import cake from '@/assets/dish-cake.png';
import salad from '@/assets/dish-salad.png';


export const categories = [{id:'all',name:'Aksiya',emoji:'🍽️'},{id:'burgers',name:'Burgerlar',emoji:'🍔'},{id:'pizza',name:'Pitsa',emoji:'🍕'},{id:'sushi',name:'Sushi',emoji:'🍣'},{id:'salads',name:'Salatlar',emoji:'🥗'},{id:'snacks',name:'Kartoshka & Snaklar',emoji:'🍟'},{id:'drinks',name:'Ichimliklar',emoji:'🥤'},{id:'desserts',name:'Desertlar',emoji:'🍰'}];
export const products = [
{id:'bon-burger',name:'Bon Burger',category:'burgers',description:'Mol go‘shti, cheddar, yangi sabzavotlar va maxsus sous',price:35000,image:burger,badge:'Bestseller'},
{id:'chicken-burger',name:'Chicken Burger',category:'burgers',description:'Qarsildoq tovuq, salat bargi va mayin sous',price:29000,image:chicken,badge:'Yangi'},
{id:'pepperoni',name:'Pepperoni',category:'pizza',description:'Pepperoni, mozzarella va pomidor sousi · 30 sm',price:69000,image:pizza,badge:''},
{id:'salmon-maki',name:'Salmon Maki',category:'sushi',description:'Losos, guruch va nori · 6 dona',price:45000,image:sushi,badge:''},
{id:'fries',name:'Kartoshka fri',category:'snacks',description:'Oltin rangli, qarsildoq kartoshka · 150 g',price:15000,image:fries,badge:''},
{id:'cola',name:'Cola',category:'drinks',description:'Muzdek va tetiklantiruvchi · 400 ml',price:10000,image:cola,badge:''},
{id:'chocolate-cake',name:'Shokoladli desert',category:'desserts',description:'Boy shokolad ta‘mi va mayin krem',price:25000,image:cake,badge:''},
{id:'caesar',name:'Sezar salati',category:'salads',description:'Yangi salat, parmesan, suxari va Sezar sousi',price:32000,image:salad,badge:''}];
export const money=(value:number)=>new Intl.NumberFormat('ru-RU').format(value);
