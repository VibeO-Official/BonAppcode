// Yandex JavaScript API keys are public browser credentials, not server secrets.
export const YANDEX_MAPS_API_KEY = '567f6cf2-3133-45f8-a0bb-a510b732fba4';