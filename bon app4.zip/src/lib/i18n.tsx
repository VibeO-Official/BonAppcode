import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type Lang = 'uz' | 'ru' | 'en';
export const LANGS: {id: Lang; label: string}[] = [{id: 'uz', label: 'O‘zb'}, {id: 'ru', label: 'Рус'}, {id: 'en', label: 'Eng'}];

const dict = {
  home: ['Asosiy', 'Главная', 'Home'],
  menu: ['Menyu', 'Меню', 'Menu'],
  delivery: ['Yetkazib berish', 'Доставка', 'Delivery'],
  news: ['Yangiliklar', 'Новости', 'News'],
  newsEmpty: ['Hozircha yangiliklar yo‘q', 'Пока нет новостей', 'No news yet'],
  newsOriginal: ['Telegramda ko‘rish', 'Открыть в Telegram', 'View on Telegram'],
  newsError: ['Yangiliklarni yuklab bo‘lmadi', 'Не удалось загрузить новости', 'Could not load news'],
  newsRetry: ['Qayta urinish', 'Повторить', 'Try again'],
  ctxCopyText: ['Matnni nusxalash', 'Копировать текст', 'Copy text'],
  ctxCopyLink: ['Havolani nusxalash', 'Копировать ссылку', 'Copy post link'],
  ctxOpen: ['Telegramda ochish', 'Открыть в Telegram', 'Open in Telegram'],
  ctxSaveMedia: ['Mediani ochish', 'Открыть медиа', 'Open media'],
  ctxCopied: ['Nusxalandi', 'Скопировано', 'Copied'],
  videoInTg: ['Videoni Telegramda ko‘rish', 'Смотреть видео в Telegram', 'Watch video in Telegram'],
  cart: ['Savatcha', 'Корзина', 'Cart'],
  sum: ['so‘m', 'сум', 'sum'],
  yourCart: ['Sizning savatingiz', 'Ваша корзина', 'Your cart'],
  cartEmpty: ['Savatchangiz hozircha bo‘sh', 'Ваша корзина пока пуста', 'Your cart is empty'],
  chooseFood: ['Taomlarni tanlash', 'Выбрать блюда', 'Choose food'],
  clearCart: ['Savatni tozalash', 'Очистить корзину', 'Clear cart'],
  total: ['Jami', 'Итого', 'Total'],
  confirmOrder: ['Buyurtmani tasdiqlash', 'Оформить заказ', 'Checkout'],
  continueShopping: ['Xaridni davom ettirish', 'Продолжить покупки', 'Continue shopping'],
  remove: ['O‘chirish', 'Удалить', 'Remove'],
  footer: ['Mazali lahzalar, har kuni.', 'Вкусные моменты каждый день.', 'Tasty moments, every day.'],
  seeMenu: ['Menyuni ko‘rish', 'Смотреть меню', 'View menu'],
  heroEyebrow: ['MAZALI TAOMLAR — YAXSHI KAYFIYAT', 'ВКУСНАЯ ЕДА — ХОРОШЕЕ НАСТРОЕНИЕ', 'TASTY FOOD — GOOD MOOD'],
  heroText1: ['Sevimli taomlaringiz endi', 'Любимые блюда теперь', 'Your favourite food is now'],
  heroText2: ['bir necha bosishda!', 'в пару кликов!', 'just a few clicks away!'],
  heroCaption: ['Katta ishtaha uchun katta tanlov', 'Большой выбор для большого аппетита', 'Big choice for a big appetite'],
  b1t: ['Eshigingizgacha yetkazamiz', 'Доставим до двери', 'Delivered to your door'],
  b1p: ['Sevimli taomlaringiz — siz istagan joyda', 'Любимые блюда — где вы захотите', 'Your favourite food, wherever you want'],
  b2t: ['Yangi va mazali', 'Свежо и вкусно', 'Fresh and tasty'],
  b2p: ['Har bir buyurtma mehr bilan tayyorlanadi', 'Каждый заказ готовится с любовью', 'Every order is made with care'],
  b3t: ['Oson buyurtma', 'Простой заказ', 'Easy ordering'],
  b3p: ['Tanlang, savatchaga qo‘shing, buyurtma bering', 'Выберите, добавьте в корзину, закажите', 'Pick, add to cart, order'],
  b4t: ['Sizga qulay to‘lov', 'Удобная оплата', 'Convenient payment'],
  b4p: ['Naqd yoki terminal orqali', 'Наличными или через терминал', 'Cash or card terminal'],
  overline: ['HAR BIR LUQMADA — ZAVQ', 'НАСЛАЖДЕНИЕ В КАЖДОМ КУСОЧКЕ', 'JOY IN EVERY BITE'],
  favourites: ['Sevimli taomlar', 'Любимые блюда', 'Favourite dishes'],
  allFood: ['Barcha taomlar', 'Все блюда', 'All dishes'],
  search: ['Taom qidirish...', 'Поиск блюд...', 'Search food...'],
  notFound: ['Taom topilmadi', 'Ничего не найдено', 'Nothing found'],
  added: ['savatchaga qo‘shildi', 'добавлен в корзину', 'added to cart'],
  add: ['savatchaga qo‘shish', 'добавить в корзину', 'add to cart'],
  newBadge: ['Yangi', 'Новинка', 'New'],
  personal: ['Shaxsiy ma’lumotlar', 'Личные данные', 'Personal details'],
  name: ['Ism', 'Имя', 'Name'],
  phone: ['Telefon raqamingiz', 'Ваш номер телефона', 'Your phone number'],
  yourOrder: ['Buyurtmangiz', 'Ваш заказ', 'Your order'],
  address: ['Yetkazib berish manzili', 'Адрес доставки', 'Delivery address'],
  mapHint: ['O‘zingizni xaritada toping va tanlash uchun bosing', 'Найдите себя на карте и нажмите, чтобы выбрать', 'Find yourself on the map and tap to select'],
  note: ['Buyurtmaga izoh', 'Комментарий к заказу', 'Order note'],
  notePh: ['Mo‘ljal, qavat yoki istaklaringiz (ixtiyoriy)', 'Ориентир, этаж или пожелания (необязательно)', 'Landmark, floor or wishes (optional)'],
  payment: ['To‘lov turi', 'Способ оплаты', 'Payment method'],
  cash: ['Naqd pul', 'Наличные', 'Cash'],
  terminal: ['Terminal', 'Терминал', 'Card terminal'],
  orderPrice: ['Buyurtma narxi', 'Стоимость заказа', 'Order price'],
  deliveryPrice: ['Yetkazib berish narxi', 'Стоимость доставки', 'Delivery price'],
  deliveryTime: ['Yetkazib berish vaqti', 'Время доставки', 'Delivery time'],
  confirmed: ['Tasdiqlanadi', 'Уточняется', 'To be confirmed'],
  foodTotal: ['Taomlar jami', 'Итого за блюда', 'Food total'],
  confirm: ['Tasdiqlash', 'Подтвердить', 'Confirm'],
  sending: ['Yuborilmoqda…', 'Отправляем…', 'Sending…'],
  operatorNote: ['Yetkazib berish narxi va vaqti operator tomonidan telefon orqali tasdiqlanadi.', 'Стоимость и время доставки оператор уточнит по телефону.', 'The operator will confirm delivery price and time by phone.'],
  sent: ['Buyurtmangiz yuborildi!', 'Ваш заказ отправлен!', 'Your order has been sent!'],
  sentText: ['Bon App operatori buyurtmangizni oldi. Yetkazib berish narxi va vaqtini telefon orqali tasdiqlaydi.', 'Оператор Bon App получил ваш заказ и уточнит стоимость и время доставки по телефону.', 'The Bon App operator received your order and will confirm delivery price and time by phone.'],
  orderNo: ['Buyurtma №', 'Заказ №', 'Order #'],
  backToMenu: ['Menyuga qaytish', 'Вернуться в меню', 'Back to menu'],
  pickFood: ['Sevimli taomlaringizni tanlang.', 'Выберите любимые блюда.', 'Pick your favourite dishes.'],
  errName: ['Ismingizni kiriting', 'Введите имя', 'Enter your name'],
  errPhone: ['Telefon raqamining 9 ta raqamini kiriting', 'Введите 9 цифр номера телефона', 'Enter the 9 digits of your phone number'],
  errAddress: ['To‘liq manzilni kiriting', 'Введите полный адрес', 'Enter the full address'],
  errGeneric: ['Buyurtma yuborilmadi. Qayta urinib ko‘ring.', 'Заказ не отправлен. Попробуйте ещё раз.', 'Order was not sent. Please try again.'],
  dTitle1: ['Taomlaringiz — siz istagan manzilga', 'Ваши блюда — по любому адресу', 'Your food, to any address'],
  dText1: ['Buyurtma berishda manzilingizni, ismingiz va telefon raqamingizni kiriting. Yetkazib berish imkoniyati, narxi va vaqti operator bilan tasdiqlanadi.', 'При заказе укажите адрес, имя и номер телефона. Возможность, стоимость и время доставки уточнит оператор.', 'When ordering, enter your address, name and phone number. The operator will confirm availability, price and time.'],
  dTitle2: ['To‘lov', 'Оплата', 'Payment'],
  dText2: ['Buyurtmani olganingizda naqd pul yoki terminal orqali to‘lashni tanlashingiz mumkin. Saytda karta ma’lumotlarini kiritish shart emas.', 'Оплатить можно при получении наличными или через терминал. Вводить данные карты на сайте не нужно.', 'Pay on delivery by cash or card terminal. No card details are needed on the site.'],
  dText3: ['Mo‘ljal, xonadon, qavat yoki buyurtmaga oid istaklaringizni izohda qoldiring.', 'Оставьте в комментарии ориентир, квартиру, этаж или пожелания.', 'Leave a landmark, apartment, floor or wishes in the note.'],
  goMenu: ['Menyuga o‘tish', 'Перейти в меню', 'Go to menu'],
} satisfies Record<string, [string, string, string]>;
export type Key = keyof typeof dict;
const idx: Record<Lang, number> = {uz: 0, ru: 1, en: 2};

const catNames: Record<string, [string, string]> = {
  all: ['Акция', 'Promo'], burgers: ['Бургеры', 'Burgers'], pizza: ['Пицца', 'Pizza'], sushi: ['Суши', 'Sushi'],
  salads: ['Салаты', 'Salads'], snacks: ['Картофель и снеки', 'Fries & snacks'], drinks: ['Напитки', 'Drinks'], desserts: ['Десерты', 'Desserts'],
};
const productText: Record<string, [string, string, string, string]> = {
  'bon-burger': ['Бон Бургер', 'Говядина, чеддер, свежие овощи и фирменный соус', 'Bon Burger', 'Beef, cheddar, fresh vegetables and signature sauce'],
  'chicken-burger': ['Чикен Бургер', 'Хрустящая курица, салат и нежный соус', 'Chicken Burger', 'Crispy chicken, lettuce and creamy sauce'],
  pepperoni: ['Пепперони', 'Пепперони, моцарелла и томатный соус · 30 см', 'Pepperoni', 'Pepperoni, mozzarella and tomato sauce · 30 cm'],
  'salmon-maki': ['Маки с лососем', 'Лосось, рис и нори · 6 шт', 'Salmon Maki', 'Salmon, rice and nori · 6 pcs'],
  fries: ['Картофель фри', 'Золотистый хрустящий картофель · 150 г', 'French fries', 'Golden crispy fries · 150 g'],
  cola: ['Кола', 'Ледяная и освежающая · 400 мл', 'Cola', 'Ice-cold and refreshing · 400 ml'],
  'chocolate-cake': ['Шоколадный десерт', 'Насыщенный шоколад и нежный крем', 'Chocolate dessert', 'Rich chocolate and soft cream'],
  caesar: ['Салат Цезарь', 'Свежий салат, пармезан, сухарики и соус Цезарь', 'Caesar salad', 'Fresh lettuce, parmesan, croutons and Caesar dressing'],
};

type Ctx = {lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string;
  cat: (id: string, fallback: string) => string; prod: (id: string, name: string, desc: string) => {name: string; description: string}};
const I18n = createContext<Ctx | undefined>(undefined);

export function I18nProvider({children}: {children: ReactNode}) {
  const [lang, setLangState] = useState<Lang>('uz');
  useEffect(() => { const saved = localStorage.getItem('lang'); if (saved === 'ru' || saved === 'en') setLangState(saved); }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = (l: Lang) => { setLangState(l); localStorage.setItem('lang', l); };
  const value: Ctx = {
    lang, setLang,
    t: k => dict[k][idx[lang]] ?? dict[k][0],
    cat: (id, fallback) => lang === 'uz' ? fallback : catNames[id]?.[lang === 'ru' ? 0 : 1] ?? fallback,
    prod: (id, name, description) => {
      const p = productText[id]; if (lang === 'uz' || !p) return {name, description};
      return lang === 'ru' ? {name: p[0], description: p[1]} : {name: p[2], description: p[3]};
    },
  };
  return <I18n.Provider value={value}>{children}</I18n.Provider>;
}
export function useI18n() { const v = useContext(I18n); if (!v) throw new Error('I18nProvider missing'); return v; }
