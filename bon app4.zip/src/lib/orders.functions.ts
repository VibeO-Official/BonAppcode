import { createServerFn } from '@tanstack/react-start';
import { orderSchema } from './order-schema';
import { orderDetails, telegramOrderText, TELEGRAM_ORDER_CHAT_ID } from './order-details';

export const submitOrder = createServerFn({method: 'POST'})
  .inputValidator(input => orderSchema.parse(input))
  .handler(async ({data}) => {
    const token = process.env['TELEGRAM_BOT_TOKEN'];
    if (!token) return {ok: false, message: 'Buyurtma yuborish vaqtincha ishlamayapti. Keyinroq urinib ko‘ring.'};
    const details = orderDetails(data);
    const text = telegramOrderText(data, details);
    if (text.length > 4096) return {ok: false, message: 'Manzil yoki izohni qisqartiring.'};
    try {
      const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({chat_id: TELEGRAM_ORDER_CHAT_ID, text, disable_web_page_preview: true}),
      });
      const payload = await response.json().catch(() => ({})) as {ok?: boolean; description?: string};
      if (response.ok && payload.ok) return {ok: true, orderId: data.requestId, total: details.total};
      console.error('Telegram order delivery rejected', response.status, payload.description);
    } catch (e) {
      console.error('Telegram order delivery failed', (e as Error)?.name);
    }
    return {ok: false, message: 'Telegram orqali yuborib bo‘lmadi. Keyinroq qayta urinib ko‘ring.'};
  });
