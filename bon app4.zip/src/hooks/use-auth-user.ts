import { useEffect, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

export function useAuthUser() {
  const [user, setUser] = useState<User | null>(null);
  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => setUser(data.user));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setUser(s?.user ?? null));
    return () => data.subscription.unsubscribe();
  }, []);
  return user;
}

export const usernameToEmail = (u: string) => `${u.trim().toLowerCase()}@bonapp.local`;
export const displayName = (u: User) => (u.user_metadata?.['username'] as string | undefined) ?? u.email?.split('@')[0] ?? '';
