import { useEffect } from 'react';

export const PROMO_INTERVAL = 5000;

export function usePromoAutoplay(next: () => void, enabled: boolean, selection: number) {
  useEffect(() => {
    if (!enabled) return;
    const timer = window.setInterval(next, PROMO_INTERVAL);
    return () => window.clearInterval(timer);
  }, [next, enabled, selection]);
}