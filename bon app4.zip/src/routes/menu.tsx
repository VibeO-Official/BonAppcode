import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { CategoryBar,MenuCatalog } from '@/components/menu-catalog';
export const Route=createFileRoute('/menu')({head:()=>({meta:[{title:'Menyu — Bon App'},{name:'description',content:'Bon App menyusi: burgerlar, pitsa, sushi, salatlar, ichimliklar va desertlar.'},{property:'og:title',content:'Bon App menyusi'},{property:'og:description',content:'Sevimli taomingizni tanlang va buyurtma bering.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),component:Menu});
function Menu(){const [selected,setSelected]=useState('all');return <main className="page-wrap"><CategoryBar selected={selected} onSelect={setSelected}/><div className="pb-6 pt-4"><MenuCatalog selected={selected}/></div></main>}
