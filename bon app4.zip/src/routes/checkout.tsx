import payCash from '@/assets/pay-cash.png';
import payTerminal from '@/assets/pay-terminal.png';
import { createFileRoute, Link } from '@tanstack/react-router';
import { useRef, useState, type FormEvent } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { ArrowRight, Banknote, CreditCard, ShoppingBag, Check, LoaderCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useShop } from '@/components/shop-provider';
import { Quantity } from '@/components/shop-shell';
import { products, money } from '@/lib/menu';
import { DeliveryMap } from '@/components/delivery-map';
import { orderSchema } from '@/lib/order-schema';
import { submitOrder } from '@/lib/orders.functions';
import { useI18n, type Key } from '@/lib/i18n';

export const Route = createFileRoute('/checkout')({
 head: () => ({meta: [
  {title: 'Buyurtmani tasdiqlash — Bon App'},
  {name: 'description', content: 'Bon App buyurtmangiz: shaxsiy ma’lumotlar, tanlangan taomlar va Yandex xaritasida yetkazib berish manzili.'},
  {property: 'og:title', content: 'Buyurtmani tasdiqlash — Bon App'},
  {property: 'og:description', content: 'Taomlaringizni tekshiring va yetkazib berish manzilini tanlang.'},
  {property: 'og:type', content: 'website'},
  {name: 'twitter:card', content: 'summary_large_image'},
 ]}),
 component: Checkout,
});

/** Keeps only digits, max 9 (the part after +998). */
export const phoneDigits = (value: string) => value.replace(/\D/g, '').slice(0, 9);
const formatPhone = (d: string) => [d.slice(0, 2), d.slice(2, 5), d.slice(5, 7), d.slice(7, 9)].filter(Boolean).join(' ');

function Checkout() {
 const {cart, count, total, clear} = useShop();
 const {t, prod} = useI18n();
 const [form, setForm] = useState({name: '', phone: '', address: '', note: '', payment: 'cash'});
 const [coordinates, setCoordinates] = useState<[number, number] | undefined>();
 const [sending, setSending] = useState(false);
 const [error, setError] = useState('');
 const [success, setSuccess] = useState<{id: string; total: number} | null>(null);
 const requestId = useRef<string | undefined>(undefined);
 const inFlight = useRef(false);
 const sendOrder = useServerFn(submitOrder);
 const update = (field: keyof typeof form, value: string) => setForm(previous => ({...previous, [field]: value}));
 async function submit(event: FormEvent<HTMLFormElement>) {
  event.preventDefault();
  if (inFlight.current) return;
  if (form.name.trim().length < 2) return setError(t('errName'));
  if (form.phone.length !== 9) return setError(t('errPhone'));
  if (form.address.trim().length < 5) return setError(t('errAddress'));
  requestId.current ??= crypto.randomUUID();
  const parsed = orderSchema.safeParse({...form, phone: '+998' + form.phone, requestId: requestId.current, coordinates,
   items: products.filter(product => cart[product.id]).map(product => ({id: product.id, quantity: cart[product.id] ?? 0}))});
  if (!parsed.success) {setError(parsed.error.issues[0]?.message ?? t('errGeneric')); return;}
  setError(''); setSending(true); inFlight.current = true;
  try {
   const result = await sendOrder({data: parsed.data});
   if (result.ok && result.orderId && result.total !== undefined) {
    setSuccess({id: result.orderId, total: result.total}); clear(); requestId.current = undefined; window.scrollTo({top: 0, behavior: 'instant'});
   } else setError(result.message ?? t('errGeneric'));
  } catch {setError(t('errGeneric'));}
  finally {setSending(false); inFlight.current = false;}
 }
 if (success) return <main className="success-page"><div className="success-icon"><Check/></div><h1>{t('sent')}</h1><p>{t('sentText')}</p><p>{t('orderNo')} {success.id.slice(0, 8).toUpperCase()}<br/>{t('foodTotal')}: <strong>{money(success.total)} {t('sum')}</strong></p><Button asChild><Link to="/menu">{t('backToMenu')} <ArrowRight/></Link></Button></main>;
 if (!count) return <main className="success-page"><div className="success-icon"><ShoppingBag/></div><h1>{t('cartEmpty')}</h1><p>{t('pickFood')}</p><Button asChild><Link to="/menu">{t('seeMenu')} <ArrowRight/></Link></Button></main>;
 const T = (k: Key) => t(k);
 return <main className="checkout-page"><div className="page-wrap checkout-inner">
  <h1 className="checkout-title">{T('confirmOrder')}</h1>
   <form onSubmit={submit} noValidate className="checkout-layout" aria-busy={sending}>
    <fieldset disabled={sending} className="checkout-form min-w-0 border-0 p-0 m-0">
    <section className="checkout-section"><h2>{T('personal')}</h2><div className="field-grid">
      <label className="field"><span className="sr-only">{T('name')}</span><input required minLength={2} autoComplete="given-name" name="name" maxLength={100} placeholder={T('name')} value={form.name} onChange={event => update('name', event.target.value)}/></label>
      <label className="field phone-field"><span className="sr-only">{T('phone')}</span><span className="phone-prefix">+998</span><input required name="phone" type="tel" inputMode="numeric" autoComplete="tel-national" placeholder="90 123 45 67" value={formatPhone(form.phone)} onChange={event => update('phone', phoneDigits(event.target.value.startsWith('998') && event.target.value.replace(/\D/g, '').length > 9 ? event.target.value.replace(/\D/g, '').slice(3) : event.target.value))}/></label>
    </div></section>
    <section className="checkout-section"><h2>{T('yourOrder')}</h2><div className="checkout-items">
     {products.filter(product => cart[product.id]).map(product => {const n = prod(product.id, product.name, product.description).name; return <div className="cart-item" key={product.id}><img src={product.image} alt={n}/><h3>{n}</h3><div className="cart-item-controls"><span className="checkout-item-price">{money(product.price*(cart[product.id]??0))} <small>{T('sum')}</small></span><Quantity id={product.id}/></div></div>;})}
    </div></section>
      <section className="checkout-section"><h2>{T('address')}</h2><p className="delivery-hint">{T('mapHint')}</p><DeliveryMap address={form.address} onAddressChange={address => {if (!inFlight.current) update('address', address);}} onSelect={(point, address) => {if (inFlight.current) return; setCoordinates(point); if (address) update('address', address);}}/></section>
    <section className="checkout-section"><h2>{T('note')}</h2><label className="field"><textarea aria-label={T('note')} name="note" maxLength={1000} placeholder={T('notePh')} value={form.note} onChange={event => update('note', event.target.value)}/></label></section>
    <section className="checkout-section"><h2>{T('payment')}</h2><div className="payment-options"><label className="payment-option"><img className="payment-photo" src={payCash} alt="" width={56} height={56}/>{T('cash')}<input type="radio" name="payment" value="cash" checked={form.payment==='cash'} onChange={() => update('payment', 'cash')}/></label><label className="payment-option"><img className="payment-photo" src={payTerminal} alt="" width={56} height={56}/>{T('terminal')}<input type="radio" name="payment" value="terminal" checked={form.payment==='terminal'} onChange={() => update('payment', 'terminal')}/></label></div></section>
    </fieldset>
    <aside className="order-summary"><h2>{T('total')}</h2><div className="summary-row"><span>{T('orderPrice')}</span><b>{money(total)} <small>{T('sum')}</small></b></div><div className="summary-row"><span>{T('deliveryPrice')}</span><b>{T('confirmed')}</b></div><div className="summary-row"><span>{T('deliveryTime')}</span><b>{T('confirmed')}</b></div><div className="cart-total"><span>{T('foodTotal')}</span><strong>{money(total)} <small>{T('sum')}</small></strong></div><Button disabled={sending} type="submit" className="wide-button">{sending ? <><LoaderCircle className="animate-spin motion-reduce:animate-none"/>{T('sending')}</> : <>{T('confirm')} <ArrowRight/></>}</Button>{error && <p className="field-error mt-3" role="alert">{error}</p>}<p className="summary-note" role="status">{T('operatorNote')}</p></aside>
  </form>
 </div></main>;
}
