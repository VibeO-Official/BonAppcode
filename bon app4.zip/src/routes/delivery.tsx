import { createFileRoute,Link } from '@tanstack/react-router';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/lib/i18n';
export const Route=createFileRoute('/delivery')({head:()=>({meta:[{title:'Yetkazib berish — Bon App'},{name:'description',content:'Bon App buyurtmalari: yetkazib berish manzili, buyurtma va to‘lov haqida.'},{property:'og:title',content:'Bon App — Yetkazib berish'},{property:'og:description',content:'Taomlarni manzilingizga buyurtma qiling.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),component:Delivery});
function Delivery(){const {t}=useI18n();return <main className="page-wrap inner-page"><p className="overline">BON APP</p><h1 className="section-title">{t('delivery')}<span className="text-primary">.</span></h1><div className="delivery-content"><section><h2>{t('dTitle1')}</h2><p>{t('dText1')}</p></section><section><h2>{t('dTitle2')}</h2><p>{t('dText2')}</p></section><section><h2>{t('note')}</h2><p>{t('dText3')}</p></section></div><Button asChild><Link to="/menu">{t('goMenu')} <ArrowRight/></Link></Button></main>}
