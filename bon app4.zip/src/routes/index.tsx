import { createFileRoute } from '@tanstack/react-router';
import { useState } from 'react';
import { CategoryBar,MenuCatalog } from '@/components/menu-catalog';
import { PromoCarousel } from '@/components/promo-carousel';
import { useI18n } from '@/lib/i18n';
import deliveryPhoto from '@/assets/service-delivery.png';
import freshPhoto from '@/assets/service-fresh.png';
import takeoutPhoto from '@/assets/service-takeout.png';
import paymentPhoto from '@/assets/service-payment.png';
export const Route=createFileRoute('/')({head:()=>({meta:[{title:'Bon App — Sevimli taomlaringiz bir necha bosishda'},{name:'description',content:'Bon App: burgerlar, pitsa, sushi va boshqa sevimli taomlar. Menyudan tanlang va onlayn buyurtma bering.'},{property:'og:title',content:'Bon App — Mazali taomlar, yaxshi kayfiyat'},{property:'og:description',content:'Sevimli taomlaringizni Bon App bilan buyurtma qiling.'},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]}),component:Home});
function Home(){const [category,setCategory]=useState('all');const {t}=useI18n();return <main className="page-wrap"><CategoryBar selected={category} onSelect={setCategory}/><PromoCarousel/><div className="benefits">{[{photo:deliveryPhoto,title:t('b1t'),text:t('b1p')},{photo:freshPhoto,title:t('b2t'),text:t('b2p')},{photo:takeoutPhoto,title:t('b3t'),text:t('b3p')},{photo:paymentPhoto,title:t('b4t'),text:t('b4p')}].map(b=><div className="benefit" key={b.title}><img className="benefit-photo" src={b.photo} alt="" width={512} height={512} loading="lazy"/><div><h3>{b.title}</h3><p>{b.text}</p></div></div>)}</div><MenuCatalog selected={category} compact/></main>}
