import { createFileRoute, Link, useNavigate } from '@tanstack/react-router';
import { useState } from 'react';
import { z } from 'zod';
import { LoaderCircle } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { usernameToEmail } from '@/hooks/use-auth-user';
import { useI18n } from '@/lib/i18n';
import video from '@/assets/friends_eating_fast_food.mp4.asset.json';

export const Route = createFileRoute('/auth')({
  head: () => ({
    meta: [
      { title: 'Kirish — Bon App' },
      { name: 'description', content: 'Bon App akkauntingizga kiring yoki login va parol bilan ro‘yxatdan o‘ting.' },
      { property: 'og:title', content: 'Kirish — Bon App' },
      { property: 'og:description', content: 'Bon App akkauntiga kirish yoki ro‘yxatdan o‘tish.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary' },
    ],
  }),
  component: AuthPage,
});

const T = {
  uz: { h: 'Mazali lahzalar shu yerda boshlanadi', sub: 'Sevimli taomlaringizni tezroq buyurtma qiling', login: 'Login', pass: 'Parol', in: 'Kirish', up: 'Ro‘yxatdan o‘tish', toUp: 'Akkauntingiz yo‘qmi? Ro‘yxatdan o‘ting', toIn: 'Akkauntingiz bormi? Kiring', skip: 'Ro‘yxatdan o‘tmasdan davom etish', bad: 'Login yoki parol noto‘g‘ri', taken: 'Bu login band', okIn: 'Xush kelibsiz!', vLogin: 'Login 3–20 belgi: faqat harflar va raqamlar', vPass: 'Parol kamida 6 belgi' },
  ru: { h: 'Вкусные моменты начинаются здесь', sub: 'Заказывайте любимую еду быстрее', login: 'Логин', pass: 'Пароль', in: 'Войти', up: 'Зарегистрироваться', toUp: 'Нет аккаунта? Зарегистрируйтесь', toIn: 'Уже есть аккаунт? Войдите', skip: 'Продолжить без регистрации', bad: 'Неверный логин или пароль', taken: 'Этот логин уже занят', okIn: 'Добро пожаловать!', vLogin: 'Логин 3–20 символов: только буквы и цифры', vPass: 'Пароль минимум 6 символов' },
  en: { h: 'Tasty moments start here', sub: 'Order your favourite food faster', login: 'Username', pass: 'Password', in: 'Sign in', up: 'Sign up', toUp: 'No account? Sign up', toIn: 'Already have an account? Sign in', skip: 'Continue without an account', bad: 'Wrong username or password', taken: 'This username is taken', okIn: 'Welcome!', vLogin: 'Username 3–20 chars: letters and digits only', vPass: 'Password must be at least 6 characters' },
};

function AuthPage() {
  const { lang } = useI18n();
  const t = T[lang] ?? T.uz;
  const navigate = useNavigate();
  const [mode, setMode] = useState<'in' | 'up'>('in');
  const [login, setLogin] = useState('');
  const [pass, setPass] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    const l = z.string().trim().regex(/^[a-zA-Z0-9]{3,20}$/).safeParse(login);
    if (!l.success) return setErr(t.vLogin);
    if (pass.length < 6 || pass.length > 72) return setErr(t.vPass);
    setBusy(true);
    const email = usernameToEmail(l.data);
    const { error } = mode === 'in'
      ? await supabase.auth.signInWithPassword({ email, password: pass })
      : await supabase.auth.signUp({ email, password: pass, options: { data: { username: l.data } } });
    setBusy(false);
    if (error) return setErr(mode === 'up' && /registered|exists/i.test(error.message) ? t.taken : mode === 'in' ? t.bad : error.message);
    toast.success(t.okIn);
    navigate({ to: '/', replace: true });
  };

  return (
    <main className="auth-page">
      <section className="auth-left">
        <h1>{t.h}</h1>
        <p className="auth-sub">{t.sub}</p>
        <form className="auth-card" onSubmit={submit}>
          <div className="auth-tabs">
            <button type="button" className={mode === 'in' ? 'active' : ''} onClick={() => { setMode('in'); setErr(''); }}>{t.in}</button>
            <button type="button" className={mode === 'up' ? 'active' : ''} onClick={() => { setMode('up'); setErr(''); }}>{t.up}</button>
          </div>
          <input value={login} onChange={e => setLogin(e.target.value)} placeholder={t.login} autoComplete="username" maxLength={20} />
          <input type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder={t.pass} autoComplete={mode === 'in' ? 'current-password' : 'new-password'} maxLength={72} />
          {err && <p className="auth-err">{err}</p>}
          <button type="submit" className="auth-submit" disabled={busy}>{busy ? <LoaderCircle className="ai-spin" /> : mode === 'in' ? t.in : t.up}</button>
          <button type="button" className="auth-switch" onClick={() => { setMode(mode === 'in' ? 'up' : 'in'); setErr(''); }}>{mode === 'in' ? t.toUp : t.toIn}</button>
        </form>
        <Link to="/" className="auth-skip">{t.skip}</Link>
      </section>
      <section className="auth-right">
        <video src={video.url} autoPlay muted loop playsInline preload="auto" aria-hidden="true" />
      </section>
    </main>
  );
}
