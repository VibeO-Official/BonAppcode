import { act, renderHook } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { usePromoAutoplay } from '@/hooks/use-promo-autoplay';

afterEach(() => vi.useRealTimers());

describe('Homepage advertising timing', () => {
  it('changes advertising every five seconds, not before', () => {
    vi.useFakeTimers();
    const next = vi.fn();
    renderHook(() => usePromoAutoplay(next, true, 0));
    act(() => vi.advanceTimersByTime(4999));
    expect(next).not.toHaveBeenCalled();
    act(() => vi.advanceTimersByTime(1));
    expect(next).toHaveBeenCalledTimes(1);
    act(() => vi.advanceTimersByTime(5000));
    expect(next).toHaveBeenCalledTimes(2);
  });
  it('stops while paused and restarts the countdown after manual selection', () => {
    vi.useFakeTimers();
    const next = vi.fn();
    const { rerender } = renderHook(({ enabled, selection }) => usePromoAutoplay(next, enabled, selection), { initialProps: { enabled: true, selection: 0 } });
    act(() => vi.advanceTimersByTime(3000));
    rerender({ enabled: true, selection: 1 });
    act(() => vi.advanceTimersByTime(4999));
    expect(next).not.toHaveBeenCalled();
    act(() => vi.advanceTimersByTime(1));
    expect(next).toHaveBeenCalledTimes(1);
    rerender({ enabled: false, selection: 1 });
    act(() => vi.advanceTimersByTime(15000));
    expect(next).toHaveBeenCalledTimes(1);
  });
});