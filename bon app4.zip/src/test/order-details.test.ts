import {describe, expect, it} from 'vitest';
import {orderSchema} from '@/lib/order-schema';
import {orderDetails, telegramOrderText, TELEGRAM_ORDER_CHAT_ID} from '@/lib/order-details';

const order = {requestId: '64d9e347-5fbe-4fea-8e66-4aa24024548a', name: 'Test Mijoz', phone: '+998901234567', address: 'Guliston, Test manzil 10', note: 'Test buyurtma', payment: 'cash' as const, items: [{id: 'bon-burger', quantity: 2}], coordinates: [40.4897, 68.7842] as [number, number]};
describe('Telegram orders', () => {
  it('uses the exact customer-provided Telegram group', () => expect(TELEGRAM_ORDER_CHAT_ID).toBe('-1004434173069'));
   it('includes customer details, dishes, total, payment and note', () => {
    const text = telegramOrderText(order, orderDetails(order));
     for (const value of [order.name, order.phone, order.address, order.note, 'Bon Burger × 2', '70', 'Naqd pul']) expect(text).toContain(value);
    expect(orderDetails(order).total).toBe(70000);
  });
   it('preserves the selected delivery location and map link', () => {
     const text = telegramOrderText(order, orderDetails(order));
     expect(text).toContain('📍 Manzil: Guliston, Test manzil 10');
     expect(text).toContain('https://yandex.uz/maps/?pt=68.7842,40.4897');
   });
  it('rejects an order without name, phone or address', () => {
    for (const field of ['name', 'phone', 'address']) expect(orderSchema.safeParse({...order, [field]: ''}).success).toBe(false);
  });
  it('rejects unknown and duplicate dishes', () => {
    expect(() => orderDetails({...order, items: [{id: 'fake', quantity: 1}]})).toThrow();
    expect(orderSchema.safeParse({...order, items: [...order.items, ...order.items]}).success).toBe(false);
  });
});