export type ReplyLanguage = 'ru' | 'uz' | 'en' | 'auto';

export function replyLanguage(text: string): ReplyLanguage {
  const words = text.toLowerCase();
  if (/[ўқғҳ]/i.test(words)) return 'uz';
  if (/[а-яё]/i.test(words)) return 'ru';
  if (/\b(salom|assalomu|men|menga|nima|qanday|qancha|qaysi|buyurtma|yetkazib|to[‘’'`ʻ]?lov|rahmat|bering|siz|taom|yaxshi|kerak|bo[‘’'`ʻ]?ladi)\b/i.test(words) || /[oOgG][‘’'`ʻ]/.test(text)) return 'uz';
  if (/\b(hello|hi|what|how|please|thanks|order|recommend|delivery|can|you|the)\b/i.test(words)) return 'en';
  return 'auto';
}

export function replyLanguageInstruction(text: string): string {
  switch (replyLanguage(text)) {
    case 'ru': return 'Язык последнего сообщения — русский. Отвечай только на естественном русском языке. Не используй узбекский или другие языки, кроме названий блюд. Язык сайта и предыдущих ответов не важен.';
    case 'uz': return 'Oxirgi xabar o‘zbek tilida. Faqat tabiiy o‘zbek tilida, xabardagi yozuvda javob bering. Sayt tili va oldingi javoblar tili muhim emas.';
    case 'en': return 'The latest message is in English. Answer only in natural English, regardless of the website language or previous replies.';
    default: return 'Identify the language of the latest user message and answer exclusively in that language. Match its script. Ignore the website language and the language of previous assistant replies.';
  }
}