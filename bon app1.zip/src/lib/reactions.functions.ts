import { createServerFn } from '@tanstack/react-start';
import { z } from 'zod';
import { REACTIONS, type ReactionSummary } from './reactions';

const postId = z.string().regex(/^\d{1,12}$/);
const visitorId = z.string().uuid();

export const getReactions = createServerFn({ method: 'POST' })
  .inputValidator(input => z.object({ postIds: z.array(postId).max(200), visitorId }).parse(input))
  .handler(async ({ data }): Promise<ReactionSummary> => {
    const summary: ReactionSummary = {};
    for (const id of data.postIds) summary[id] = { counts: {}, mine: null };
    if (!data.postIds.length) return summary;
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const { data: rows, error } = await supabaseAdmin.from('news_reactions').select('post_id,visitor_id,emoji').in('post_id', data.postIds);
    if (error) throw new Error('Reactions unavailable');
    for (const r of rows ?? []) {
      const s = summary[r.post_id];
      if (!s) continue;
      s.counts[r.emoji] = (s.counts[r.emoji] ?? 0) + 1;
      if (r.visitor_id === data.visitorId) s.mine = r.emoji;
    }
    return summary;
  });

export const setReaction = createServerFn({ method: 'POST' })
  .inputValidator(input => z.object({ postId, visitorId, emoji: z.enum(REACTIONS).nullable() }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
    const q = supabaseAdmin.from('news_reactions');
    const { error } = data.emoji
      ? await q.upsert({ post_id: data.postId, visitor_id: data.visitorId, emoji: data.emoji, created_at: new Date().toISOString() }, { onConflict: 'post_id,visitor_id' })
      : await q.delete().eq('post_id', data.postId).eq('visitor_id', data.visitorId);
    if (error) throw new Error('Could not save reaction');
    return { ok: true };
  });
