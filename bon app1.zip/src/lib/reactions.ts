export const REACTIONS = ['👍','❤️','🔥','😂','😍','👏','🤩','😋','🍔','🍕','🎉','💯','😮','🤔','😢','😡','👎','🙏','🥰','😎','🤤','⚡','🏆','💔'] as const;

export type ReactionSummary = Record<string, { counts: Record<string, number>; mine: string | null }>;

/** One reaction per visitor per post: same emoji again removes it, another emoji replaces it. */
export function nextReaction(current: string | null, picked: string): string | null {
  return current === picked ? null : picked;
}
