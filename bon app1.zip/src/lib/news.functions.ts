import { createServerFn } from '@tanstack/react-start';
import { NEWS_FEED_URL, parseChannelPage } from './telegram-news';

export const getNews = createServerFn({ method: 'GET' }).handler(async () => {
  const response = await fetch(NEWS_FEED_URL, { headers: { 'User-Agent': 'Mozilla/5.0 BonAppSite' } });
  if (!response.ok) throw new Error('News unavailable');
  return parseChannelPage(await response.text());
});
