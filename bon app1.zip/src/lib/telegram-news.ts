export const NEWS_CHANNEL_URL = 'https://t.me/BonAppNews';
export const NEWS_FEED_URL = 'https://t.me/s/BonAppNews';

export type NewsPost = { id: string; body: string; publishedAt: string; sourceUrl: string; image: string | null; video: string | null; round: boolean; poster: string | null; voice: string | null; waveform: number[]; duration: string | null };

export function newsDate(iso: string, lang: 'uz' | 'ru' | 'en') {
  const date = new Date(new Date(iso).getTime() + 5 * 60 * 60 * 1000);
  const months = {
    uz: ['yanvar','fevral','mart','aprel','may','iyun','iyul','avgust','sentabr','oktabr','noyabr','dekabr'],
    ru: ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'],
    en: ['January','February','March','April','May','June','July','August','September','October','November','December'],
  };
  return `${date.getUTCDate()} ${months[lang][date.getUTCMonth()]} ${date.getUTCFullYear()}`;
}

function decode(html: string) {
  return html
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
    .trim();
}

/** Parses the public channel preview page (t.me/s/<channel>) into posts, newest first. */
export function parseChannelPage(html: string): NewsPost[] {
  const chunks = html.split('<div class="tgme_widget_message_wrap').slice(1);
  const posts: NewsPost[] = [];
  for (const chunk of chunks) {
    if (/class="[^"]*\bservice_message\b/.test(chunk.slice(0, 400))) continue;
    const id = chunk.match(/data-post="BonAppNews\/(\d+)"/)?.[1];
    const time = chunk.match(/<time datetime="([^"]+)"/)?.[1];
    if (!id || !time) continue;
    const textHtml = chunk.match(/<div class="tgme_widget_message_text[^"]*"[^>]*>([\s\S]*?)<\/div>/)?.[1] ?? '';
    const image = chunk.match(/tgme_widget_message_photo_wrap[^>]*background-image:url\('([^']+)'\)/)?.[1] ?? null;
    const video = chunk.match(/<video[^>]*\bsrc="([^"]+)"/)?.[1]?.replace(/&amp;/g, '&') ?? null;
    const round = /tgme_widget_message_roundvideo/.test(chunk);
    const poster = chunk.match(/(?:video_thumb|roundvideo_thumb)[^>]*background-image:url\('([^']+)'\)/)?.[1] ?? null;
    const voiceTag = chunk.match(/<audio[^>]*tgme_widget_message_voice[^>]*>/)?.[0] ?? '';
    const voice = voiceTag.match(/\bsrc="([^"]+)"/)?.[1]?.replace(/&amp;/g, '&') ?? null;
    const waveform = (voiceTag.match(/data-waveform="([^"]*)"/)?.[1] ?? '').split(',').filter(Boolean).map(Number);
    const duration = chunk.match(/tgme_widget_message_voice_duration[^>]*>([^<]*)</)?.[1]?.trim() || null;
    const body = decode(textHtml);
    if (!body && !image && !video && !poster && !voice) continue;
    posts.push({ id, body, publishedAt: new Date(time).toISOString(), sourceUrl: `${NEWS_CHANNEL_URL}/${id}`, image, video, round, poster, voice, waveform, duration });
  }
  return posts.reverse();
}
