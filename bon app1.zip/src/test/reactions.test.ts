import { describe, expect, it } from 'vitest';
import { nextReaction, REACTIONS } from '@/lib/reactions';

describe('news reactions', () => {
  it('picking the same reaction again removes it', () => { expect(nextReaction('🔥', '🔥')).toBeNull(); });
  it('picking another reaction replaces the old one', () => { expect(nextReaction('🔥', '❤️')).toBe('❤️'); });
  it('offers many reactions', () => { expect(REACTIONS.length).toBeGreaterThanOrEqual(20); });
});
