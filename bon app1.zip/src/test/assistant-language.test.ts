import { describe, expect, it } from 'vitest';
import { replyLanguage } from '@/lib/assistant-language';

describe('assistant reply language follows the latest message', () => {
  it('answers the reported menu question in Russian', () => {
    expect(replyLanguage('что мне лучше заказать из вашего меню?')).toBe('ru');
  });
  it('recognizes Uzbek in Latin script', () => {
    expect(replyLanguage('Qanday buyurtma beraman?')).toBe('uz');
  });
  it('recognizes Uzbek in Cyrillic script', () => {
    expect(replyLanguage('Қандай таом буюртма қилсам бўлади?')).toBe('uz');
  });
  it('recognizes English', () => {
    expect(replyLanguage('What should I order from your menu?')).toBe('en');
  });
  it('leaves other languages to the model instead of forcing the site language', () => {
    expect(replyLanguage('¿Qué me recomiendas pedir?')).toBe('auto');
  });
});