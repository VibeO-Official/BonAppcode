import { describe, expect, it } from 'vitest';
import { parseChannelPage } from '@/lib/telegram-news';

const post = (id: number, inner: string, extra = '') => `<div class="tgme_widget_message_wrap js-widget_message_wrap"><div class="tgme_widget_message ${extra} js-widget_message" data-post="BonAppNews/${id}">${inner}<a class="tgme_widget_message_date" href="#"><time datetime="2026-10-17T14:58:30+00:00"></time></a></div></div>`;

describe('BonAppNews channel feed', () => {
  it('reads text posts newest first and links to the original', () => {
    const html = post(1, '<div class="tgme_widget_message_text js-message_text">Первая</div>') + post(2, '<div class="tgme_widget_message_text js-message_text">Вторая &amp; <b>акция</b></div>');
    const result = parseChannelPage(html);
    expect(result.map(p => p.body)).toEqual(['Вторая & акция', 'Первая']);
    expect(result[0]?.sourceUrl).toBe('https://t.me/BonAppNews/2');
  });
  it('skips service messages like channel created', () => {
    expect(parseChannelPage(post(1, '<div class="tgme_widget_message_text">Channel created</div>', 'service_message'))).toEqual([]);
  });
  it('keeps photo posts', () => {
    const r = parseChannelPage(post(3, `<a class="tgme_widget_message_photo_wrap" style="width:1px;background-image:url('https://cdn/x.jpg')"></a>`));
    expect(r[0]?.image).toBe('https://cdn/x.jpg');
  });
});
describe('video posts', () => {
  it('reads videos and round videos', () => {
    const v = parseChannelPage(post(4, `<video src="https://cdn/v.mp4?a=1&amp;b=2" class="tgme_widget_message_video"></video>`));
    expect(v[0]?.video).toBe('https://cdn/v.mp4?a=1&b=2');
    expect(v[0]?.round).toBe(false);
    const r = parseChannelPage(post(5, `<video class="tgme_widget_message_roundvideo" src="https://cdn/r.mp4"></video>`));
    expect(r[0]?.round).toBe(true);
  });
});

describe('voice messages', () => {
  it('keeps a voice-only post with its audio link and waveform', async () => {
    const { parseChannelPage } = await import('@/lib/telegram-news');
    const html = '<div class="tgme_widget_message_wrap"><div data-post="BonAppNews/15"><audio class="tgme_widget_message_voice js-message_voice" src="https://cdn/x.ogg?a=1&amp;b=2" data-waveform="0,31,15"><time class="tgme_widget_message_voice_duration js-message_voice_duration">0:07</time><time datetime="2026-10-17T15:00:00+00:00"></time></div></div>';
    const [post] = parseChannelPage(html);
    expect(post?.voice).toBe('https://cdn/x.ogg?a=1&b=2');
    expect(post?.waveform).toEqual([0, 31, 15]);
    expect(post?.duration).toBe('0:07');
  });
});
