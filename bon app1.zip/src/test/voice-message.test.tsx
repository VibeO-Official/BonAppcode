import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import { VoiceMessage } from '@/components/news-media';

describe('VoiceMessage', () => {
  it('renders a playable audio with the post duration', () => {
    const { container } = render(<VoiceMessage src="https://cdn/x.ogg" waveform={[0, 31, 15]} duration="0:07" />);
    expect(container.querySelector('audio')?.getAttribute('src')).toBe('https://cdn/x.ogg');
    expect(screen.getByRole('button', { name: 'Play' })).toBeTruthy();
    expect(screen.getByText('0:07')).toBeTruthy();
  });
});
