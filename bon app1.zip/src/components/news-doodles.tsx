/** Telegram-style doodle wallpaper, drawn fully in SVG code (no image files). */
import type { ReactElement } from 'react';
const S = 'currentColor';

function Burger() { return <g><path d="M2 12a12 9 0 0 1 24 0z"/><path d="M1 15h26"/><path d="M2 19q3-2 6 0t6 0 6 0 6 0"/><rect x="2" y="22" width="24" height="5" rx="2.5"/><path d="M9 7l1 1M15 6l1 1M20 8l1 1"/></g>; }
function Pizza() { return <g><path d="M2 4q13-6 26 0L15 30z"/><path d="M4 8q11-5 22 0"/><circle cx="12" cy="12" r="2"/><circle cx="18" cy="15" r="2"/><circle cx="15" cy="21" r="1.5"/></g>; }
function Cup() { return <g><path d="M3 9h18l-2 17H5z"/><path d="M21 13h3a3 3 0 0 1 0 7h-4"/><path d="M8 2q2 3 0 5M13 1q2 3 0 5"/></g>; }
function Heart() { return <path d="M12 21C3 14 1 9 4 5.5s7-1 8 2c1-3 5-5.5 8-2s1 8.5-8 15.5z"/>; }
function Star() { return <path d="M12 2l3 7 7 .8-5.3 4.8 1.6 7.4L12 18.3 5.7 22l1.6-7.4L2 9.8 9 9z"/>; }
function Sparkle() { return <path d="M12 1q1 10 11 11-10 1-11 11-1-10-11-11 10-1 11-11z"/>; }
function Snow() { return <g><path d="M12 1v22M2.5 6.5l19 11M21.5 6.5l-19 11"/><path d="M9 3l3 2 3-2M9 21l3-2 3 2"/></g>; }
function Gift() { return <g><rect x="2" y="10" width="22" height="15" rx="1"/><path d="M1 6h24v4H1zM13 6v19"/><path d="M13 6q-6-7-8-2t8 2q6-7 8-2t-8 2"/></g>; }
function Donut() { return <g><ellipse cx="14" cy="13" rx="13" ry="10"/><ellipse cx="14" cy="12" rx="4" ry="2.5"/><path d="M6 9l2 1M20 7l1 2M22 15l-2 1M8 17l2-1"/></g>; }
function IceCream() { return <g><path d="M4 12l7 17 7-17"/><path d="M3 12a8 8 0 0 1 16 0z"/><path d="M8 17l6-4M9 22l4-3"/></g>; }
function Balloon() { return <g><ellipse cx="10" cy="10" rx="8" ry="10"/><path d="M8 20l2 2 2-2M10 22q4 5-1 10"/></g>; }
function Cane() { return <g><path d="M6 30V9a5 5 0 0 1 10 0v2"/><path d="M6 14l3 -2M6 20l3-2M6 26l3-2"/></g>; }
function Note() { return <g><path d="M8 20V3l12-2v16"/><ellipse cx="5" cy="20" rx="3.5" ry="2.5"/><ellipse cx="17" cy="17" rx="3.5" ry="2.5"/></g>; }
function Smile() { return <g><circle cx="12" cy="12" r="11"/><circle cx="8" cy="9" r="1"/><circle cx="16" cy="9" r="1"/><path d="M7 15q5 5 10 0"/></g>; }
function Cupcake() { return <g><path d="M4 14l3 13h12l3-13z"/><path d="M3 14q-2-6 5-7 1-6 6-5 6 0 5 5 6 1 4 7z"/><path d="M10 14l1 13M16 14l-1 13"/><circle cx="13" cy="2" r="1.5"/></g>; }
function Fries() { return <g><path d="M4 12l3 16h12l3-16z"/><path d="M7 12V2M11 12V0M15 12V1M19 12V3"/><path d="M8 18q5 4 10 0"/></g>; }
function Plane() { return <g><path d="M1 12L26 2 19 25l-6-8z"/><path d="M26 2L13 17v8l3-5"/></g>; }
function Cake() { return <g><rect x="2" y="14" width="26" height="12" rx="2"/><path d="M2 19q3 3 6.5 0t6.5 0 6.5 0 6.5 0"/><path d="M8 14V8M15 14V7M22 14V8"/><path d="M8 4q1 1.5 0 3M15 3q1 1.5 0 3M22 4q1 1.5 0 3"/></g>; }
function Croissant() { return <g><path d="M2 18q2-14 12-14t12 14q-4 2-7-3-2 5-5 5t-5-5q-3 5-7 3z"/><path d="M9 7l2 8M19 7l-2 8"/></g>; }
function Drink() { return <g><path d="M3 4h18l-3 24H6z"/><path d="M4 11h16"/><path d="M14 4l4-4h4"/></g>; }
function Ornament() { return <g><circle cx="10" cy="15" r="8"/><rect x="7" y="4" width="6" height="3"/><path d="M10 4V1M3 13h14M3 17h14"/></g>; }
function House() { return <g><path d="M2 14L15 3l13 11"/><path d="M5 12v15h20V12"/><rect x="12" y="18" width="6" height="9"/><rect x="7" y="15" width="4" height="4"/><rect x="19" y="15" width="4" height="4"/><path d="M21 7V2h3v8"/></g>; }
function Tree() { return <g><path d="M14 1l5 7h-3l6 7h-4l7 8H3l7-8H6l6-7H9z"/><path d="M12 23h4v5h-4z"/><circle cx="11" cy="14" r="1"/><circle cx="17" cy="18" r="1"/><circle cx="14" cy="9" r="1"/></g>; }
function Bell() { return <g><path d="M4 21q2-2 2-9a8 8 0 0 1 16 0q0 7 2 9z"/><path d="M11 24a3 3 0 0 0 6 0"/><path d="M14 1v3"/><path d="M8 4q-4-2-6 2 4 1 6-2zM20 4q4-2 6 2-4 1-6-2z"/></g>; }
function Camera() { return <g><rect x="1" y="7" width="26" height="18" rx="3"/><circle cx="14" cy="16" r="6"/><circle cx="14" cy="16" r="3"/><path d="M9 7l2-4h6l2 4"/><circle cx="23" cy="11" r="1"/></g>; }
function Cherry() { return <g><circle cx="7" cy="22" r="5"/><circle cx="20" cy="23" r="5"/><path d="M7 17q3-10 9-15 2 10 4 16"/><path d="M16 2q5-1 8 3-5 1-8-3z"/></g>; }
function Bear() { return <g><circle cx="14" cy="10" r="7"/><circle cx="8" cy="4" r="2.5"/><circle cx="20" cy="4" r="2.5"/><circle cx="11.5" cy="9" r=".8"/><circle cx="16.5" cy="9" r=".8"/><path d="M12 13q2 2 4 0"/><path d="M7 16q-3 4-1 11h16q2-7-1-11"/><path d="M11 22h6"/></g>; }
function Lantern() { return <g><path d="M9 4h10l2 4H7z"/><path d="M8 8v15h12V8"/><path d="M6 23h16v3H6z"/><path d="M14 4V1"/><path d="M14 13q3 3 0 6-3-3 0-6z"/></g>; }
function Snowman() { return <g><circle cx="14" cy="9" r="5"/><circle cx="14" cy="21" r="7"/><path d="M8 4h12M10 4V0h8v4"/><circle cx="12" cy="8" r=".7"/><circle cx="16" cy="8" r=".7"/><path d="M14 10l3 1-3 .5"/><path d="M7 18l-5-3M21 18l5-3"/><circle cx="14" cy="19" r=".7"/><circle cx="14" cy="23" r=".7"/></g>; }
function Cat() { return <g><path d="M3 24q-2-10 8-11 9 0 12 5 4 6-2 7H5"/><path d="M19 14l2-5 2 4 3-3v6"/><path d="M21 17h.1M24 17h.1"/><path d="M3 24q-3 3 1 4"/></g>; }
function Mitten() { return <g><path d="M8 26V12q0-9 7-9t7 9v4l3-3q3 1 1 5l-5 5v3z"/><path d="M7 22h15"/></g>; }
function Sock() { return <g><path d="M8 1h11v15l4 6q2 5-3 7-3 1-6-2l-7-8V1z"/><path d="M8 6h11M8 9h11"/></g>; }
function Pretzel() { return <g><path d="M14 22q-12-2-11-11 2-8 9-5 4 3 2 10-2 7 5 9 6-1 6-8 0-8-7-7-6 2-7 9"/></g>; }
function Pancake() { return <g><ellipse cx="14" cy="23" rx="13" ry="3"/><path d="M3 20q11 4 22 0M3 16q11 4 22 0M4 12q10 4 20 0"/><ellipse cx="14" cy="11" rx="10" ry="2.5"/><path d="M11 8h6v3h-6z"/></g>; }
function Paw() { return <g><path d="M8 20q0-6 6-6t6 6q0 4-6 3t-6-3z"/><circle cx="7" cy="12" r="2"/><circle cx="11" cy="8" r="2"/><circle cx="17" cy="8" r="2"/><circle cx="21" cy="12" r="2"/></g>; }
function Envelope() { return <g><rect x="1" y="5" width="26" height="18" rx="2"/><path d="M1 7l13 9 13-9"/><path d="M14 13q-3-3-1-4 1 0 1 1 0-1 1-1 2 1-1 4z"/></g>; }
function Popcorn() { return <g><path d="M5 12l3 16h12l3-16z"/><path d="M10 12l1 16M18 12l-1 16"/><path d="M4 12q-2-4 2-5 0-4 4-3 2-4 5-2 4-2 5 2 4 0 3 4 3 2 0 4z"/></g>; }
function Moon() { return <path d="M18 2a11 11 0 1 0 8 17A9 9 0 0 1 18 2z"/>; }
function Muffin() { return <g><path d="M6 15l2 11h12l2-11"/><path d="M4 15q-2-8 6-9 4-5 9 0 7 1 5 9z"/><circle cx="11" cy="11" r=".8"/><circle cx="17" cy="10" r=".8"/></g>; }
function Glasses() { return <g><path d="M3 2h8q0 9-4 10-4-1-4-10zM17 2h8q0 9-4 10-4-1-4-10z"/><path d="M7 12v13M21 12v13M3 26h8M17 26h8"/></g>; }
function Wreath() { return <g><circle cx="14" cy="14" r="11"/><circle cx="14" cy="14" r="6"/><path d="M10 25l4-4 4 4M12 21h4"/><circle cx="8" cy="8" r="1"/><circle cx="21" cy="10" r="1"/><circle cx="19" cy="20" r="1"/></g>; }
function Cookie() { return <g><circle cx="14" cy="14" r="12"/><circle cx="9" cy="10" r="1.3"/><circle cx="17" cy="8" r="1"/><circle cx="18" cy="16" r="1.4"/><circle cx="10" cy="18" r="1"/></g>; }
function Ticket() { return <g><path d="M2 8h24v4a2 2 0 0 0 0 4v4H2v-4a2 2 0 0 0 0-4z"/><path d="M18 8v12" strokeDasharray="2 2"/></g>; }
function Skate() { return <g><path d="M4 2h8v10l12 4q3 1 3 5H4z"/><path d="M2 26h24M8 21v5M20 21v5"/><path d="M7 6h5M7 9h5"/></g>; }
function Dot({ r = 2 }: { r?: number }) { return <circle cx={r} cy={r} r={r}/>; }

const shapes = [Burger, House, Pizza, Bell, Cup, Tree, Donut, Camera, Cherry, Gift, Bear, Lantern, Note, Snowman, Cupcake, Cat, Fries, Mitten, Plane, Sock, Cake, Pretzel, Croissant, Pancake, Drink, Paw, Ornament, Envelope, IceCream, Popcorn, Balloon, Muffin, Cane, Glasses, Smile, Wreath, Cookie, Ticket, Skate, Moon];
const fillers = [Star, Sparkle, Heart, Snow];
const W = 960, H = 960;
function rng(seed: number) { return () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; }; }
const r = rng(20261018);
const items: [ReactElement, number, number, number, number][] = [];
// Scattered placement: random positions with minimum spacing (no visible grid),
// shapes drawn in shuffled order so neighbours never repeat. Wraps seamlessly.
const placed: [number, number, number][] = [];
function free(x: number, y: number, rad: number) {
  for (const [px, py, pr] of placed) {
    let dx = Math.abs(px - x), dy = Math.abs(py - y);
    dx = Math.min(dx, W - dx); dy = Math.min(dy, H - dy);
    if (dx * dx + dy * dy < (rad + pr) ** 2) return false;
  }
  return true;
}
function add(el: () => ReactElement, rad: number, minS: number, maxS: number, tries = 60) {
  for (let t = 0; t < tries; t++) {
    const x = r() * W, y = r() * H;
    if (!free(x, y, rad)) continue;
    placed.push([x, y, rad]);
    const sc = minS + r() * (maxS - minS);
    const node = el();
    // draw copies across edges so the tile wraps without cut-off doodles
    for (const ox of [-W, 0, W]) for (const oy of [-H, 0, H]) {
      const X = x + ox, Y = y + oy;
      if (X < -40 || X > W + 10 || Y < -40 || Y > H + 10) continue;
      items.push([node, X - 14 * sc, Y - 14 * sc, r() * 70 - 35, sc]);
    }
    return true;
  }
  return false;
}
const order = [...shapes].sort(() => r() - 0.5);
for (let pass = 0; pass < 3; pass++) for (const Sh of order) add(() => <Sh/>, 30, 1.05, 1.6);
for (let i = 0; i < 160; i++) { const F = fillers[i % fillers.length]!; add(() => <F/>, 11, 0.38, 0.65, 20); }
for (let i = 0; i < 140; i++) add(() => <Dot r={1.3 + r()}/>, 7, 1, 1, 15);

export function NewsDoodles() {
  return (
    <svg className="tg-doodles" aria-hidden width="100%" height="100%">
      <defs>
        <pattern id="tg-doodle-tile" width={W} height={H} patternUnits="userSpaceOnUse">
          <g fill="none" stroke={S} strokeWidth="1.15" strokeLinecap="round" strokeLinejoin="round">
            {items.map(([el, x, y, rot, sc], i) => <g key={i} transform={`translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${rot.toFixed(1)} ${(14*sc).toFixed(1)} ${(14*sc).toFixed(1)}) scale(${sc.toFixed(2)})`}>{el}</g>)}
          </g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#tg-doodle-tile)"/>
    </svg>
  );
}
