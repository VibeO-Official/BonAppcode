import { useEffect, useRef, useState } from 'react';
import { MessageCircle, Send, X, LoaderCircle } from 'lucide-react';
import aiChatLogo from '@/assets/bon-app-avatar-single-ring.png';
import { useI18n } from '@/lib/i18n';
import { products, money } from '@/lib/menu';
import { replyLanguageInstruction } from '@/lib/assistant-language';

// Runs fully in the visitor's browser via WebGPU — no API key, no server.
const MODEL_ID = 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC';

type Msg = { role: 'user' | 'assistant'; content: string; time: string };

const menuText = products.map(p => `- ${p.name}: ${money(p.price)} so'm (${p.description})`).join('\n');
const SYSTEM_PROMPT = `You are "Bon App AI", the friendly assistant of the Bon App fast-food website in Uzbekistan.
STRICT RULE: always reply in the SAME language the visitor wrote in (Uzbek, Russian, English or any other). Keep answers short (2-5 sentences), friendly, with an emoji sometimes.
Website facts:
- Pages: Home (/), Menu (/menu), Delivery (/delivery), Checkout (/checkout). The site works in Uzbek, Russian, English (language switcher at top right) and has a light/dark theme button in the header.
- Categories: Burgers, Pizza, Sushi, Salads, Fries & Snacks, Drinks, Desserts.
- Menu with prices:
${menuText}
- How to order: 1) open Menu, 2) press "+" / add to cart on dishes, 3) click the Cart button in the header, 4) press Checkout, 5) enter name, phone and address (or pick the point on the map), optional comment, 6) choose payment: cash or card terminal on delivery, 7) confirm. The order goes straight to our operators, who call back to confirm.
- Delivery price and time are confirmed by the operator by phone after the order. Takeout is also possible.
- Payment: cash or terminal (card) upon receipt. No online prepayment needed.
- Food is cooked fresh for every order.
If you don't know something (e.g. exact hours, phone number), say the operator will clarify after ordering. Never invent dishes that are not on the menu.`;

const UI = {
  uz: { title: 'Bon App AI Yordamchi', online: 'Onlayn', hello: 'Salom! 👋 Men Bon App AI yordamchisiman. Menyu, buyurtma berish, yetkazib berish va to‘lov haqida savollaringizga javob beraman. Qanday yordam kerak?', ph: 'Savol bering...', loading: 'AI yuklanmoqda', noGpu: 'Brauzeringiz WebGPU’ni qo‘llab-quvvatlamaydi. Chrome yoki Edge’ning so‘nggi versiyasini ishlating.', err: 'Xatolik yuz berdi. Qayta urinib ko‘ring.', limit: '⏳ Sizning bepul savollar limitingiz tugadi. Limitlar 12 soatdan keyin qayta to‘ladi — shunda hamma AI yordamchidan foydalana oladi. Keyinroq qayting!', q: ['Qanday buyurtma beraman?', 'Eng mashhur taom qaysi?', 'Yetkazib berish qancha turadi?', 'Qanday to‘lasam bo‘ladi?'] },
  ru: { title: 'Bon App AI Помощник', online: 'Онлайн', hello: 'Привет! 👋 Я AI-помощник Bon App. Отвечу на вопросы о меню, заказе, доставке и оплате. Чем могу помочь?', ph: 'Задайте вопрос...', loading: 'Загрузка ИИ', noGpu: 'Ваш браузер не поддерживает WebGPU. Используйте свежую версию Chrome или Edge.', err: 'Произошла ошибка. Попробуйте ещё раз.', limit: '⏳ У вас закончились бесплатные вопросы. Лимиты пополнятся через 12 часов — так помощника хватит на всех. Возвращайтесь позже!', q: ['Как заказать еду?', 'Что у вас самое популярное?', 'Сколько стоит доставка?', 'Как можно оплатить?'] },
  en: { title: 'Bon App AI Assistant', online: 'Online', hello: 'Hi! 👋 I’m the Bon App AI assistant. Ask me about the menu, ordering, delivery and payment. How can I help?', ph: 'Ask a question...', loading: 'Loading AI', noGpu: 'Your browser doesn’t support WebGPU. Please use a recent Chrome or Edge.', err: 'Something went wrong. Please try again.', limit: '⏳ You’ve used up your free questions. The limit refills in 12 hours — this way everyone gets to use the assistant. Come back later!', q: ['How do I order food?', 'What is your most popular dish?', 'How much is delivery?', 'How can I pay?'] },
};

const now = () => new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

// Free-question limit: 5 questions per 12 hours per visitor (stored in this browser).
const LIMIT_KEY = 'bonapp-ai-limit';
const MAX_QUESTIONS = 5;
const WINDOW_MS = 12 * 60 * 60 * 1000;

function readLimit(): { count: number; resetAt: number } {
  try {
    const raw = localStorage.getItem(LIMIT_KEY);
    if (raw) {
      const d = JSON.parse(raw);
      if (typeof d.count === 'number' && typeof d.resetAt === 'number') {
        if (Date.now() < d.resetAt) return d;
      }
    }
  } catch { /* ignore */ }
  return { count: 0, resetAt: Date.now() + WINDOW_MS };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let enginePromise: Promise<any> | null = null;

export function AiAssistant() {
  const { lang } = useI18n();
  const ui = UI[lang] ?? UI.uz;
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [used, setUsed] = useState(0);
  useEffect(() => { setUsed(readLimit().count); }, []);
  const limited = used >= MAX_QUESTIONS;
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' }); }, [msgs, busy, progress]);
  const panelRef = useRef<HTMLDivElement>(null);
  const fabRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (panelRef.current?.contains(t) || fabRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('pointerdown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('pointerdown', onDown); document.removeEventListener('keydown', onKey); };
  }, [open]);
  useEffect(() => { if (open) setTimeout(() => inputRef.current?.focus(), 250); }, [open, busy]);

  const getEngine = (silent = false) => {
    if (!enginePromise) {
      enginePromise = (async () => {
        if (!('gpu' in navigator)) throw new Error('nogpu');
        const webllm = await import('@mlc-ai/web-llm');
        if (!silent) setProgress(0);
        const engine = await webllm.CreateMLCEngine(MODEL_ID, {
          initProgressCallback: (r: { progress: number }) => { if (!silent) setProgress(Math.round(r.progress * 100)); },
        });
        setProgress(null);
        return engine;
      })().catch(e => { enginePromise = null; setProgress(null); throw e; });
    }
    return enginePromise;
  };

  // Preload the model in the background shortly after the page opens,
  // so the chat answers instantly when the visitor writes. On repeat
  // visits the weights come from the browser cache, so this is fast.
  useEffect(() => {
    if (!('gpu' in navigator)) return;
    const t = setTimeout(() => { getEngine(true).catch(() => {}); }, 2500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const send = async (text: string) => {
    const q = text.trim();
    if (!q || busy || limited) return;
    const lim = readLimit();
    if (lim.count >= MAX_QUESTIONS) {
      setUsed(lim.count);
      setMsgs(m => [...m, { role: 'user', content: q, time: now() }, { role: 'assistant', content: ui.limit, time: now() }]);
      setInput('');
      return;
    }
    lim.count += 1;
    setUsed(lim.count);
    try { localStorage.setItem(LIMIT_KEY, JSON.stringify(lim)); } catch { /* ignore */ }
    setInput('');
    const history: Msg[] = [...msgs, { role: 'user', content: q, time: now() }];
    setMsgs(history);
    setBusy(true);
    try {
      const engine = await getEngine();
      const stream = await engine.chat.completions.create({
        stream: true, temperature: 0.4, max_tokens: 400,
        messages: [{ role: 'system', content: `${SYSTEM_PROMPT}\n\nPRIORITY FOR THIS REPLY: ${replyLanguageInstruction(q)}` }, ...history.map(m => ({ role: m.role, content: m.content }))],
      });
      let acc = '';
      setMsgs(m => [...m, { role: 'assistant', content: '', time: now() }]);
      for await (const chunk of stream) {
        acc += chunk.choices[0]?.delta?.content ?? '';
        setMsgs(m => { const c = [...m]; c[c.length - 1] = { ...(c[c.length - 1] as Msg), content: acc }; return c; });
      }
    } catch (e) {
      setMsgs(m => [...m, { role: 'assistant', content: (e as Error).message === 'nogpu' ? ui.noGpu : ui.err, time: now() }]);
    } finally { setBusy(false); }
  };

  const lastEmpty = busy && msgs[msgs.length - 1]?.role === 'assistant' && !msgs[msgs.length - 1]?.content;
  const showTyping = busy && (msgs[msgs.length - 1]?.role === 'user' || lastEmpty);

  return (
    <>
      <div ref={panelRef} className={`ai-panel ${open ? 'is-open' : ''}`} role="dialog" aria-label={ui.title} aria-hidden={!open}>
        <div className="ai-head">
          <div className="ai-avatar"><img src={aiChatLogo} alt="Bon App" className="ai-bot-logo" /></div>
          <div className="ai-head-text"><b>{ui.title}</b><span><i className="ai-dot" />{ui.online}</span></div>
          <button className="ai-close" onClick={() => setOpen(false)} aria-label="Close"><X /></button>
        </div>
        <div className="ai-list" ref={listRef}>
          <Bubble role="assistant" content={ui.hello} time="" />
          {msgs.map((m, i) => (m.content ? <Bubble key={i} {...m} /> : null))}
          {progress !== null && (
            <div className="ai-progress"><LoaderCircle className="ai-spin" /><span>{ui.loading} · {progress}%</span><div><i style={{ width: `${progress}%` }} /></div></div>
          )}
          {showTyping && progress === null && <div className="ai-row"><div className="ai-bot"><img src={aiChatLogo} alt="Bon App" className="ai-bot-logo" /></div><div className="ai-bubble ai-typing"><i /><i /><i /></div></div>}
        </div>
        <div className="ai-chips">
          {ui.q.map(q => <button key={q} onClick={() => send(q)} disabled={busy || limited}>{q}</button>)}
        </div>
        <form className="ai-form" onSubmit={e => { e.preventDefault(); send(input); }}>
          <input ref={inputRef} value={input} onChange={e => setInput(e.target.value)} placeholder={limited ? ui.limit : ui.ph} disabled={limited} />
          <button type="submit" disabled={busy || limited || !input.trim()} aria-label="Send"><Send /></button>
        </form>
      </div>
      <button ref={fabRef} className={`ai-fab ${open ? 'is-open' : ''}`} onClick={() => setOpen(o => !o)} aria-label={ui.title}>
        <span className="ai-fab-icon">{open ? <X /> : <MessageCircle />}</span>
        {!open && <i className="ai-fab-dot" />}
      </button>
    </>
  );
}

function Bubble({ role, content, time }: Msg) {
  return (
    <div className={`ai-row ${role === 'user' ? 'is-user' : ''}`}>
      {role === 'assistant' && <div className="ai-bot"><img src={aiChatLogo} alt="Bon App" className="ai-bot-logo" /></div>}
      <div><div className="ai-bubble">{content}</div>{time && <small>{time}</small>}</div>
    </div>
  );
}
