import { useEffect, useRef, useState } from 'react';
import { Pause, Play, Volume2, VolumeX } from 'lucide-react';

const R = 136;
const C = 2 * Math.PI * R;

/** Telegram-style round video ("кружочек"): silent autoplay preview, tap to play with sound. */
export function RoundVideo({ src, poster }: { src: string; poster: string | null }) {
  const ref = useRef<HTMLVideoElement>(null);
  const [active, setActive] = useState(false);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const v = ref.current;
    if (!v) return;
    const onTime = () => setProgress(v.duration ? v.currentTime / v.duration : 0);
    const onEnd = () => { setActive(false); v.muted = true; v.loop = true; void v.play().catch(() => {}); };
    v.addEventListener('timeupdate', onTime);
    v.addEventListener('ended', onEnd);
    return () => { v.removeEventListener('timeupdate', onTime); v.removeEventListener('ended', onEnd); };
  }, []);

  const toggle = () => {
    const v = ref.current;
    if (!v) return;
    if (!active) {
      v.muted = false; v.loop = false; v.currentTime = 0;
      setActive(true); setPaused(false);
      void v.play().catch(() => setPaused(true));
      return;
    }
    if (v.paused) { void v.play(); setPaused(false); } else { v.pause(); setPaused(true); }
  };

  return (
    <button type="button" className="tg-round-wrap" onClick={toggle} aria-label="Video">
      <video
        ref={ref}
        className="tg-round"
        src={src}
        poster={poster ?? undefined}
        muted
        autoPlay
        loop
        playsInline
        preload="auto"
        onError={() => setFailed(true)}
      />
      {active && (
        <svg className="tg-round-ring" viewBox="0 0 280 280" aria-hidden>
          <circle cx="140" cy="140" r={R} strokeDasharray={C} strokeDashoffset={C * (1 - progress)} />
        </svg>
      )}
      <span className="tg-round-badge" aria-hidden>{active ? <Volume2 size={14} /> : <VolumeX size={14} />}</span>
      {(failed || (active && paused)) && <span className="tg-play" aria-hidden><Play size={28} /></span>}
    </button>
  );
}

/** Video Telegram does not publish on the web: poster with a play button that opens the post. */
export function TelegramOnlyVideo({ poster, href, round, label }: { poster: string; href: string; round: boolean; label: string }) {
  return (
    <a className={round ? 'tg-round-wrap' : 'tg-video-link'} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}>
      <img className={round ? 'tg-round' : ''} src={poster} alt={label} loading="lazy" />
      <span className="tg-play" aria-hidden><Play size={28} /></span>
    </a>
  );
}

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/** Telegram-style voice message: play button, waveform progress, duration. */
export function VoiceMessage({ src, waveform, duration }: { src: string; waveform: number[]; duration: string | null }) {
  const ref = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [time, setTime] = useState<string | null>(null);
  const bars = waveform.length ? waveform : Array.from({ length: 48 }, () => 8);
  const step = Math.max(1, Math.ceil(bars.length / 48));
  const shown = bars.filter((_, i) => i % step === 0);

  const toggle = () => {
    const a = ref.current;
    if (!a) return;
    if (a.paused) void a.play(); else a.pause();
  };
  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const a = ref.current;
    if (!a || !a.duration) return;
    const r = e.currentTarget.getBoundingClientRect();
    a.currentTime = ((e.clientX - r.left) / r.width) * a.duration;
    if (a.paused) void a.play();
  };

  return (
    <div className="tg-voice">
      <audio
        ref={ref}
        src={src}
        preload="metadata"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => { setPlaying(false); setProgress(0); setTime(null); }}
        onTimeUpdate={e => { const a = e.currentTarget; if (a.duration) { setProgress(a.currentTime / a.duration); setTime(fmt(a.currentTime)); } }}
      />
      <button type="button" className="tg-voice-btn" onClick={toggle} aria-label={playing ? 'Pause' : 'Play'}>
        {playing ? <Pause size={20} /> : <Play size={20} />}
      </button>
      <div className="tg-voice-main">
        <div className="tg-wave" onClick={seek}>
          {shown.map((v, i) => (
            <span key={i} className={i / shown.length < progress ? 'is-played' : ''} style={{ height: `${Math.max(12, (v / 31) * 100)}%` }} />
          ))}
        </div>
        <span className="tg-voice-time">{time ?? duration ?? ''}</span>
      </div>
    </div>
  );
}
