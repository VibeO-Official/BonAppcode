import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ChevronDown, Copy, ExternalLink, Image as ImageIcon, Link2 } from 'lucide-react';
import { toast } from 'sonner';
import { REACTIONS } from '@/lib/reactions';
import { useI18n } from '@/lib/i18n';

export type MenuTarget = { postId: string; x: number; y: number; text: string; link: string; media: string | null; mine: string | null };

const QUICK = REACTIONS.slice(0, 7);

/** Telegram Desktop-style context menu: reaction strip on top, actions below. */
export function NewsContextMenu({ target, onClose, onReact }: { target: MenuTarget; onClose: () => void; onReact: (postId: string, emoji: string) => void }) {
  const { t } = useI18n();
  const ref = useRef<HTMLDivElement>(null);
  const [all, setAll] = useState(false);
  const [pos, setPos] = useState({ left: target.x, top: target.y });

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const { width, height } = el.getBoundingClientRect();
    setPos({
      left: Math.max(8, Math.min(target.x, window.innerWidth - width - 8)),
      top: Math.max(8, Math.min(target.y, window.innerHeight - height - 8)),
    });
  }, [target.x, target.y, all]);

  useEffect(() => {
    const close = (e: Event) => { if (!ref.current?.contains(e.target as Node)) onClose(); };
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('pointerdown', close, true);
    document.addEventListener('scroll', onClose, true);
    window.addEventListener('resize', onClose);
    document.addEventListener('keydown', key);
    return () => {
      document.removeEventListener('pointerdown', close, true);
      document.removeEventListener('scroll', onClose, true);
      window.removeEventListener('resize', onClose);
      document.removeEventListener('keydown', key);
    };
  }, [onClose]);

  const copy = async (value: string) => {
    try { await navigator.clipboard.writeText(value); toast.success(t('ctxCopied')); } catch { /* clipboard blocked */ }
    onClose();
  };
  const react = (e: string) => { onReact(target.postId, e); onClose(); };

  return (
    <div ref={ref} className="tg-ctx" style={{ left: pos.left, top: pos.top }} role="menu" onContextMenu={e => e.preventDefault()}>
      {all ? (
        <div className="tg-ctx-grid">
          {REACTIONS.map(e => <button key={e} type="button" className={target.mine === e ? 'is-mine' : ''} onClick={() => react(e)}>{e}</button>)}
        </div>
      ) : (
        <div className="tg-ctx-strip">
          {QUICK.map(e => <button key={e} type="button" className={target.mine === e ? 'is-mine' : ''} onClick={() => react(e)}>{e}</button>)}
          <button type="button" className="tg-ctx-more" aria-label="More" onClick={() => setAll(true)}><ChevronDown size={18} /></button>
        </div>
      )}
      <div className="tg-ctx-list">
        {target.text && <button type="button" role="menuitem" onClick={() => void copy(target.text)}><Copy size={17} />{t('ctxCopyText')}</button>}
        <button type="button" role="menuitem" onClick={() => void copy(target.link)}><Link2 size={17} />{t('ctxCopyLink')}</button>
        {target.media && <a role="menuitem" href={target.media} target="_blank" rel="noopener noreferrer" onClick={onClose}><ImageIcon size={17} />{t('ctxSaveMedia')}</a>}
        <a role="menuitem" href={target.link} target="_blank" rel="noopener noreferrer" onClick={onClose}><ExternalLink size={17} />{t('ctxOpen')}</a>
      </div>
    </div>
  );
}
