import { createFileRoute, useRouter } from '@tanstack/react-router';
import { queryOptions, useQuery, useQueryClient, useSuspenseQuery } from '@tanstack/react-query';
import { useServerFn } from '@tanstack/react-start';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { NewsContextMenu, type MenuTarget } from '@/components/news-context-menu';
import { RoundVideo, TelegramOnlyVideo, VoiceMessage } from '@/components/news-media';
import { ArrowDown, ArrowUpRight, BadgeCheck, Newspaper, SmilePlus } from 'lucide-react';
import { NewsDoodles } from '@/components/news-doodles';
import avatar from '@/assets/bon-app-avatar-single-ring.png';
import { Button } from '@/components/ui/button';
import { getNews } from '@/lib/news.functions';
import { getReactions, setReaction } from '@/lib/reactions.functions';
import { REACTIONS, nextReaction, type ReactionSummary } from '@/lib/reactions';
import { useI18n } from '@/lib/i18n';
import { NEWS_CHANNEL_URL, newsDate } from '@/lib/telegram-news';

const newsQuery = queryOptions({ queryKey: ['news'], queryFn: () => getNews(), refetchInterval: 30000 });
export const Route = createFileRoute('/news')({
  head: () => ({ meta: [
    { title: 'Yangiliklar — Bon App' }, { name: 'description', content: 'Bon App yangiliklari va Telegram kanalidagi so‘nggi e’lonlar.' },
    { property: 'og:title', content: 'Yangiliklar — Bon App' }, { property: 'og:description', content: 'Bon App yangiliklari va so‘nggi e’lonlar.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  loader: ({ context }) => context.queryClient.ensureQueryData(newsQuery),
  component: News,
  errorComponent: NewsError,
  notFoundComponent: () => <main className="page-wrap inner-page">Bon App</main>,
});
function NewsError({ reset }: { reset: () => void }) {
  const { t } = useI18n();
  const router = useRouter();
  return <main className="page-wrap inner-page"><p role="alert">{t('newsError')}</p><Button onClick={() => { void router.invalidate(); reset(); }}>{t('newsRetry')}</Button></main>;
}

function useVisitorId() {
  const [id, setId] = useState<string | null>(null);
  useEffect(() => {
    let v = localStorage.getItem('bonapp-visitor');
    if (!v) { v = crypto.randomUUID(); localStorage.setItem('bonapp-visitor', v); }
    setId(v);
  }, []);
  return id;
}
function timeOf(iso: string) {
  const d = new Date(new Date(iso).getTime() + 5 * 3600 * 1000);
  return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
}

function News() {
  const { t, lang } = useI18n();
  const { data: posts } = useSuspenseQuery(newsQuery);
  const ordered = [...posts].reverse(); // oldest on top, newest at the bottom like Telegram
  const visitorId = useVisitorId();
  const ids = ordered.map(p => p.id);
  const fetchReactions = useServerFn(getReactions);
  const saveReaction = useServerFn(setReaction);
  const queryClient = useQueryClient();
  const reactionsKey = ['news-reactions', ids.join(','), visitorId];
  const { data: reactions } = useQuery({
    queryKey: reactionsKey, enabled: !!visitorId, refetchInterval: 15000,
    queryFn: () => fetchReactions({ data: { postIds: ids, visitorId: visitorId! } }),
  });
  const [picker, setPicker] = useState<string | null>(null);
  const [menu, setMenu] = useState<MenuTarget | null>(null);
  const closeMenu = useCallback(() => setMenu(null), []);
  const pressTimer = useRef<number | null>(null);
  const openMenu = (post: (typeof posts)[number], x: number, y: number) => {
    setPicker(null);
    setMenu({ postId: post.id, x, y, text: post.body, link: post.sourceUrl, media: post.video ?? post.voice ?? post.image ?? post.poster, mine: reactions?.[post.id]?.mine ?? null });
  };
  const cancelPress = () => { if (pressTimer.current) { clearTimeout(pressTimer.current); pressTimer.current = null; } };
  const feedRef = useRef<HTMLDivElement>(null);
  const [away, setAway] = useState(false);
  const [unseen, setUnseen] = useState(0);
  const seenCount = useRef(posts.length);
  useLayoutEffect(() => {
    const el = feedRef.current; if (!el) return;
    const added = posts.length - seenCount.current; seenCount.current = posts.length;
    if (away && added > 0) setUnseen(u => u + added); else el.scrollTop = el.scrollHeight;
  }, [posts.length]); // eslint-disable-line react-hooks/exhaustive-deps
  const onScroll = () => { const el = feedRef.current; if (!el) return; const far = el.scrollHeight - el.scrollTop - el.clientHeight > 240; setAway(far); if (!far) setUnseen(0); };
  const toLatest = () => { const el = feedRef.current; if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' }); setUnseen(0); };

  const react = async (postId: string, emoji: string) => {
    if (!visitorId) return;
    setPicker(null);
    const current = reactions?.[postId]?.mine ?? null;
    const next = nextReaction(current, emoji);
    queryClient.setQueryData<ReactionSummary>(reactionsKey, old => {
      const copy: ReactionSummary = structuredClone(old ?? {});
      const s = copy[postId] ?? (copy[postId] = { counts: {}, mine: null });
      if (current) { s.counts[current] = Math.max(0, (s.counts[current] ?? 1) - 1); if (!s.counts[current]) delete s.counts[current]; }
      if (next) s.counts[next] = (s.counts[next] ?? 0) + 1;
      s.mine = next;
      return copy;
    });
    try { await saveReaction({ data: { postId, visitorId, emoji: next as (typeof REACTIONS)[number] | null } }); }
    finally { void queryClient.invalidateQueries({ queryKey: ['news-reactions'] }); }
  };

  let lastDay = '';
  return <main className="page-wrap inner-page news-page">
    <div className="section-heading"><div><p className="overline">BON APP</p><h1 className="section-title">{t('news')}<span className="text-primary">.</span></h1></div>
      <Button asChild variant="outline"><a href={NEWS_CHANNEL_URL} target="_blank" rel="noopener noreferrer">Telegram <ArrowUpRight size={16}/></a></Button></div>
    <div className="tg-channel">
      <img src={avatar} alt="Bon App" className="tg-channel-avatar"/>
      <div className="tg-channel-info"><b>Bon App News <BadgeCheck size={16} className="tg-verified"/></b><span><i className="tg-live"/>{ordered.length} {lang === 'ru' ? 'публикаций' : lang === 'en' ? 'posts' : 'ta post'}</span></div>
      <Button asChild size="sm"><a href={NEWS_CHANNEL_URL} target="_blank" rel="noopener noreferrer">{lang === 'ru' ? 'Подписаться' : lang === 'en' ? 'Join' : 'Obuna bo‘lish'}</a></Button>
    </div>
    {ordered.length === 0 ? <div className="news-empty"><Newspaper size={40}/><h2>{t('newsEmpty')}</h2></div> :
      <div className="tg-feed-wrap"><NewsDoodles/><div className="tg-feed" ref={feedRef} onScroll={onScroll} onClick={() => setPicker(null)}>
        {ordered.map((post, i) => {
          const lastInGroup = i === ordered.length - 1 || newsDate(ordered[i + 1]!.publishedAt, lang) !== newsDate(post.publishedAt, lang) || new Date(ordered[i + 1]!.publishedAt).getTime() - new Date(post.publishedAt).getTime() > 15 * 60000;
          const day = newsDate(post.publishedAt, lang);
          const showDay = day !== lastDay; lastDay = day;
          const r = reactions?.[post.id];
          const chips = Object.entries(r?.counts ?? {}).sort((a, b) => b[1] - a[1]);
          return <div key={post.id} className="tg-row">
            {showDay && <div className="tg-day"><span>{day}</span></div>}
            <div className="tg-line">
            {lastInGroup ? <img src={avatar} alt="" className="tg-avatar" aria-hidden/> : <span className="tg-avatar-space"/>}
            <article className={`tg-bubble${post.round && !post.body ? ' tg-bubble-round' : ''}${menu?.postId === post.id ? ' is-selected' : ''}`}
              onContextMenu={e => { if ((e.target as HTMLElement).closest('a[href]:not(.tg-video-link), .tg-chip')) return; e.preventDefault(); openMenu(post, e.clientX, e.clientY); }}
              onTouchStart={e => { const tch = e.touches[0]; cancelPress(); if (!tch) return; pressTimer.current = window.setTimeout(() => openMenu(post, tch.clientX, tch.clientY), 500); }}
              onTouchEnd={cancelPress} onTouchMove={cancelPress}>
              {post.image && <img src={post.image} alt={post.body.slice(0, 120) || 'Bon App'} loading="lazy" draggable={false}/>}
              {post.video ? (post.round ? <RoundVideo src={post.video} poster={post.poster}/> : <video className="tg-video" src={post.video} poster={post.poster ?? undefined} controls playsInline preload="metadata"/>)
                : post.poster && <TelegramOnlyVideo poster={post.poster} href={post.sourceUrl} round={post.round} label={t('videoInTg')}/>}
              <div className="tg-body">
                <div className="tg-author">Bon App News</div>
                {post.voice && <VoiceMessage src={post.voice} waveform={post.waveform} duration={post.duration}/>}
                {post.body && <p>{post.body}</p>}
                <div className="tg-meta"><a href={post.sourceUrl} target="_blank" rel="noopener noreferrer">{t('newsOriginal')}</a><time dateTime={post.publishedAt}>{timeOf(post.publishedAt)}</time></div>
                <div className="tg-reactions" onClick={e => e.stopPropagation()}>
                  {chips.map(([emoji, count]) => <button key={emoji} type="button" className={`tg-chip${r?.mine === emoji ? ' is-mine' : ''}`} onClick={() => void react(post.id, emoji)} aria-pressed={r?.mine === emoji}>{emoji} <b>{count}</b></button>)}
                  <button type="button" className="tg-chip tg-add" aria-label="Reaction" onClick={() => setPicker(picker === post.id ? null : post.id)}><SmilePlus size={16}/></button>
                  {picker === post.id && <div className="tg-picker" role="menu">
                    {REACTIONS.map(e => <button key={e} type="button" role="menuitem" className={r?.mine === e ? 'is-mine' : ''} onClick={() => void react(post.id, e)}>{e}</button>)}
                  </div>}
                </div>
              </div>
            </article>
            </div>
          </div>;
        })}
      </div>
      {away && <button type="button" className="tg-down" onClick={toLatest} aria-label="Latest">{unseen > 0 && <span>{unseen}</span>}<ArrowDown size={20}/></button>}
      </div>}
    {menu && <NewsContextMenu target={menu} onClose={closeMenu} onReact={(id, e) => void react(id, e)}/>}
  </main>;
}
