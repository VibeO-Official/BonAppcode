import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { ArrowRight, ClipboardList } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { products, money } from '@/lib/menu';
import { useI18n } from '@/lib/i18n';
import { readOrders, type SavedOrder } from '@/lib/order-history';

export const Route = createFileRoute('/orders')({
  head: () => ({meta: [
    {title: 'Buyurtmalarim — Bon App'},
    {name: 'description', content: 'Bon App’dagi barcha buyurtmalaringiz: sana, vaqt va tarkib.'},
    {property: 'og:title', content: 'Buyurtmalarim — Bon App'},
    {property: 'og:description', content: 'Barcha buyurtmalaringiz tarixi.'},
    {property: 'og:type', content: 'website'},
    {name: 'twitter:card', content: 'summary_large_image'},
  ]}),
  component: Orders,
});

function Orders() {
  const {t, lang, prod} = useI18n();
  const [orders, setOrders] = useState<SavedOrder[] | null>(null);
  useEffect(() => setOrders(readOrders()), []);
  const L = lang === 'ru' ? {title: 'Мои заказы', empty: 'Вы ещё ничего не заказывали.', date: 'Дата', time: 'Время', pay: 'Оплата', cash: 'Наличные', term: 'Терминал'}
    : lang === 'uz' ? {title: 'Buyurtmalarim', empty: 'Siz hali hech narsa buyurtma qilmagansiz.', date: 'Sana', time: 'Vaqt', pay: 'To‘lov', cash: 'Naqd', term: 'Terminal'}
    : {title: 'My orders', empty: 'You haven’t ordered anything yet.', date: 'Date', time: 'Time', pay: 'Payment', cash: 'Cash', term: 'Terminal'};
  const locale = lang === 'ru' ? 'ru-RU' : lang === 'uz' ? 'uz-UZ' : 'en-GB';
  if (orders && !orders.length) return <main className="success-page"><div className="success-icon"><ClipboardList/></div><h1>{L.title}</h1><p>{L.empty}</p><Button asChild><Link to="/menu">{t('seeMenu')} <ArrowRight/></Link></Button></main>;
  return <main className="checkout-page"><div className="page-wrap checkout-inner">
    <h1 className="checkout-title">{L.title}</h1>
    <div className="orders-list">{(orders ?? []).map(o => {
      const d = new Date(o.createdAt);
      return <section key={o.id} className="checkout-section order-card">
        <header className="order-card-head"><strong>№ {o.id.slice(0, 8).toUpperCase()}</strong>
          <span>{L.date}: {d.toLocaleDateString('ru-RU')}</span>
          <span>{L.time}: {d.toLocaleTimeString(locale, {hour: '2-digit', minute: '2-digit'})}</span></header>
        <ul className="order-card-items">{o.items.map(i => { const p = products.find(x => x.id === i.id);
          return <li key={i.id}><span>{p ? prod(p.id, p.name, p.description).name : i.id} × {i.quantity}</span><span>{money(i.price * i.quantity)} {t('sum')}</span></li>; })}</ul>
        <footer className="order-card-foot"><span>{L.pay}: {o.payment === 'cash' ? L.cash : L.term}</span><strong>{money(o.total)} {t('sum')}</strong></footer>
      </section>; })}</div>
  </div></main>;
}
