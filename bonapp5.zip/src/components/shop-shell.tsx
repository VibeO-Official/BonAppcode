import { Link,useLocation } from '@tanstack/react-router';
import { useEffect, useRef, useState } from 'react';
import { ShoppingBag,ArrowRight,Minus,Plus,ArrowUpRight,Trash2,X,ChevronDown,Moon,Sun,Send,UserRound,LogOut,LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog,DialogPortal,DialogOverlay,DialogTitle,DialogDescription } from '@/components/ui/dialog';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import { useShop } from './shop-provider';
import { products,money } from '@/lib/menu';
import { useI18n, LANGS, type Lang } from '@/lib/i18n';
import logo from '@/assets/bon-app-logo.png';
import { useAuthUser, displayName } from '@/hooks/use-auth-user';
import { supabase } from '@/integrations/supabase/client';
export function Brand(){return <span className="brand"><img src={logo} alt="Bon App" width={972} height={478}/></span>}
export function Flag({lang}:{lang:Lang}){return <span className={`flag flag-${lang}`} aria-hidden="true"/>}
function showAddedToast(message:string){
 let host=document.querySelector('.added-toasts');
 if(!host){host=document.createElement('div');host.className='added-toasts';host.setAttribute('aria-live','polite');document.body.appendChild(host)}
 const el=document.createElement('div');el.className='added-toast';
 const icon=document.createElement('span');icon.className='added-toast-icon';icon.innerHTML='<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';
 const text=document.createElement('span');text.className='added-toast-text';text.textContent=message;
 const bar=document.createElement('span');bar.className='added-toast-bar';
 el.append(icon,text,bar);host.appendChild(el);
 setTimeout(()=>{el.classList.add('leaving');setTimeout(()=>el.remove(),300)},2600);
}
export function flyToCart(from:HTMLElement,opts?:{image?:string|undefined;message?:string}){
 if(typeof window==='undefined')return;
 if(opts?.message)showAddedToast(opts.message);
 from.classList.remove('added-pop');void from.offsetWidth;from.classList.add('added-pop');setTimeout(()=>from.classList.remove('added-pop'),900);
 const target=document.querySelector('.site-header .cart-target') as HTMLElement|null;
 const bump=()=>target?.animate([{transform:'scale(1)'},{transform:'scale(1.18)'},{transform:'scale(1)'}],{duration:350,easing:'ease-out'});
 if(window.matchMedia('(prefers-reduced-motion: reduce)').matches||!target){bump();return}
 const card=from.closest('.product,.cart-item');const srcImg=card?.querySelector('img') as HTMLImageElement|null;
 const start=(srcImg??from).getBoundingClientRect();const end=target.getBoundingClientRect();
 const img=document.createElement('img');img.src=opts?.image??srcImg?.src??'';img.className='fly-image';img.alt='';
 const size=Math.min(start.width,140);
 Object.assign(img.style,{left:`${start.left+start.width/2-size/2}px`,top:`${start.top+start.height/2-size/2}px`,width:`${size}px`,height:`${size}px`});
 document.body.appendChild(img);
 const dx=end.left+end.width/2-(start.left+start.width/2),dy=end.top+end.height/2-(start.top+start.height/2);
 const anim=img.animate([
  {transform:'translate(0,0) scale(1)',opacity:1},
  {transform:`translate(${dx*0.45}px,${dy*0.45-90}px) scale(0.7)`,opacity:1,offset:0.45},
  {transform:`translate(${dx}px,${dy}px) scale(0.12)`,opacity:0.6},
 ],{duration:800,easing:'cubic-bezier(.5,0,.3,1)'});
 anim.onfinish=()=>{img.remove();bump()};
}
function ThemeToggle(){
 const [dark,setDark]=useState(false);
 useEffect(()=>{let saved=false;try{saved=localStorage.getItem('bon-app-theme')==='dark'}catch{}setDark(saved);document.documentElement.classList.toggle('dark',saved)},[]);
 const toggle=()=>{const next=!dark;setDark(next);document.documentElement.classList.toggle('dark',next);try{localStorage.setItem('bon-app-theme',next?'dark':'light')}catch{}};
 const label=dark?'Светлая тема':'Тёмная тема';
 return <Button type="button" variant="nav" size="icon" className="theme-toggle" onClick={toggle} aria-label={label} title={label} aria-pressed={dark}>{dark?<Sun/>:<Moon/>}</Button>;
}
export function Quantity({id}:{id:string}){const {cart,change}=useShop();const {t,prod}=useI18n();const item=products.find(x=>x.id===id);const name=item?prod(item.id,item.name,item.description).name:id;return <div className="quantity"><Button type="button" variant="ghost" size="icon" aria-label={`- ${id}`} onClick={()=>change(id,-1)}><Minus/></Button><span>{cart[id]??0}</span><Button type="button" variant="ghost" size="icon" aria-label={`+ ${id}`} disabled={(cart[id]??0)>=20} onClick={e=>{flyToCart(e.currentTarget,{image:item?.image,message:`${name} ${t('added')}`});change(id,1)}}><Plus/></Button></div>}
function LanguageSwitcher(){
 const {lang,setLang}=useI18n();const [open,setOpen]=useState(false);const ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(!open)return;const close=(e:MouseEvent)=>{if(!ref.current?.contains(e.target as Node))setOpen(false)};document.addEventListener('mousedown',close);return()=>document.removeEventListener('mousedown',close)},[open]);
 return <div className="lang-switch" ref={ref}><button type="button" className="language" aria-haspopup="listbox" aria-expanded={open} onClick={()=>setOpen(o=>!o)}><Flag lang={lang}/><ChevronDown size={16} className={open?'rotate-180 transition-transform':'transition-transform'}/></button>
 {open&&<ul className="lang-menu" role="listbox">{LANGS.map(l=><li key={l.id}><button type="button" role="option" aria-selected={lang===l.id} className={lang===l.id?'active':''} onClick={()=>{setLang(l.id);setOpen(false)}}><Flag lang={l.id}/>{l.label}</button></li>)}</ul>}</div>}
function AccountButton(){const user=useAuthUser();const {lang}=useI18n();const label=lang==='ru'?'Вход':lang==='en'?'Sign in':'Kirish';
 if(!user)return <Button asChild variant="nav" size="icon" className="account-btn"><Link to="/auth" aria-label={label} title={label}><LogIn/></Link></Button>;
 return <Button type="button" variant="nav" className="account-btn" title="Logout" onClick={()=>supabase.auth.signOut()}><UserRound/><span>{displayName(user)}</span><LogOut size={14}/></Button>}
export function ShopHeader(){const {count,setCartOpen}=useShop();const {t}=useI18n();const location=useLocation();return <header className="site-header"><div className="header-inner"><Link to="/" aria-label="Bon App"><Brand/></Link><nav><Link to="/" className={location.pathname==='/'?'active':''}>{t('home')}</Link><Link to="/menu" className={location.pathname==='/menu'?'active':''}>{t('menu')}</Link><Link to="/orders" className={location.pathname==='/orders'?'active':''}>{t('myOrders')}</Link><Link to="/delivery" className={location.pathname==='/delivery'?'active':''}>{t('delivery')}</Link></nav><div className="header-actions"><ThemeToggle/><AccountButton/><Button variant="nav" className="cart-target" onClick={()=>setCartOpen(true)}><ShoppingBag/><span>{t('cart')}</span>{count>0&&<b className="cart-count">{count}</b>}</Button><LanguageSwitcher/></div></div></header>}
export function CartDialog(){
 const {cart,cartOpen,setCartOpen,count,total,clear,change}=useShop();const {t,prod}=useI18n();
 return <Dialog open={cartOpen} onOpenChange={setCartOpen}><DialogPortal><DialogOverlay className="cart-backdrop"/><DialogPrimitive.Content className="cart-drawer">
  <div className="cart-drawer-header"><DialogTitle className="cart-drawer-title">{t('yourCart')} <span className="small-count">{count}</span></DialogTitle><DialogPrimitive.Close asChild><Button type="button" variant="ghost" size="icon" className="cart-close" aria-label="X"><X/></Button></DialogPrimitive.Close></div>
  <DialogDescription className="sr-only">{t('yourCart')}</DialogDescription>
  {count===0?<div className="empty-cart"><ShoppingBag/><h3>{t('cartEmpty')}</h3><Button onClick={()=>setCartOpen(false)}>{t('chooseFood')} <ArrowRight/></Button></div>:<>
   <div className="cart-tools"><Button type="button" variant="ghost" size="sm" className="cart-clear" onClick={clear}><Trash2 size={14}/>{t('clearCart')}</Button></div>
   <div className="cart-items">{products.filter(p=>cart[p.id]).map(p=>{const n=prod(p.id,p.name,p.description).name;return <div className="cart-item" key={p.id}><img src={p.image} alt={n}/><div><h3>{n.toUpperCase()}</h3><p>{money(p.price*(cart[p.id]??0))} <small>{t('sum')}</small></p></div><div className="cart-item-controls"><Button type="button" variant="ghost" size="icon" className="cart-remove" aria-label={t('remove')} title={t('remove')} onClick={()=>change(p.id,-(cart[p.id]??0))}><Trash2 size={14}/></Button><Quantity id={p.id}/></div></div>})}</div>
   <div className="cart-drawer-footer"><div className="cart-total"><span>{t('total')}:</span><strong>{money(total)} {t('sum')}</strong></div><Button asChild size="lg" className="wide-button"><Link to="/checkout" onClick={()=>setCartOpen(false)}>{t('confirmOrder')} <ArrowRight/></Link></Button><Button type="button" variant="ghost" className="cart-continue" onClick={()=>setCartOpen(false)}>{t('continueShopping')}</Button></div>
  </>}
 </DialogPrimitive.Content></DialogPortal></Dialog>;
}
export function Footer(){const {t,lang}=useI18n();const L=lang==='ru'?{nav:'Навигация',about:'Мы любим вашу улыбку. Ташкентские бургеры, хрустящая курица и пицца.',rights:'Все права защищены.',tg:'Telegram-канал'}:lang==='uz'?{nav:'Navigatsiya',about:'Biz sizning tabassumingizni sevamiz. Toshkentda burgerlar, qarsildoq tovuq va pitsa.',rights:'Barcha huquqlar himoyalangan.',tg:'Telegram kanal'}:{nav:'Navigation',about:'We love your smile. Burgers, crispy chicken and pizza in Tashkent.',rights:'All rights reserved.',tg:'Telegram channel'};return <footer className="site-footer"><div className="footer-inner"><div className="footer-about"><Link to="/" aria-label="Bon App"><Brand/></Link><p>{L.about}</p><a className="footer-social" href="https://t.me/BonAppNews" target="_blank" rel="noopener noreferrer" aria-label={L.tg} title={L.tg}><Send size={18}/></a></div><nav className="footer-nav" aria-label={L.nav}><h3>{L.nav}</h3><Link to="/">{t('home')}</Link><Link to="/menu">{t('menu')}</Link><Link to="/orders">{t('myOrders')}</Link><Link to="/delivery">{t('delivery')}</Link></nav></div><div className="footer-bottom"><span>© {new Date().getFullYear()} BON APP. {L.rights}</span><b>We love your smile</b></div></footer>}
