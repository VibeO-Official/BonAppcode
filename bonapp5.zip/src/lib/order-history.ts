export type SavedOrder = {id: string; createdAt: string; total: number; payment: 'cash' | 'terminal'; address: string; items: {id: string; quantity: number; price: number}[]};
const KEY = 'bon-app-orders';
export function readOrders(): SavedOrder[] {
  try { const v = JSON.parse(localStorage.getItem(KEY) ?? '[]'); return Array.isArray(v) ? v : []; } catch { return []; }
}
export function saveOrder(order: SavedOrder) {
  const list = [order, ...readOrders().filter(o => o.id !== order.id)];
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch {}
}
